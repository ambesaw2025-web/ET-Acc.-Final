import "./global.css";

import React from "react";
import { Toaster } from "@/components/ui/toaster";
import { createRoot } from "react-dom/client";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Index from "./pages/Index";
import NotFound from "./pages/NotFound";
import Login from "./pages/Login";
import Setup from "./pages/Setup";
import Dashboard from "./pages/Dashboard";
import Reports from "./pages/Reports";
import Settings from "./pages/Settings";
import Workflow from "./pages/Workflow";
import Help from "./pages/Help";
import Recover from "./pages/Recover";
import Activation from "./pages/Activation";
import { SearchModal } from "@/components/modals/SearchModal";
import { ErrorBoundary } from "@/components/system/ErrorBoundary";

const queryClient = new QueryClient();

import { AppProvider } from "@/state/app";

function GlobalSearchMount(){
  const [open, setOpen] = React.useState(false);
  React.useEffect(()=>{
    const openFn = () => setOpen(true);
    window.addEventListener("open-search", openFn as any);
    return () => window.removeEventListener("open-search", openFn as any);
  },[]);
  return <SearchModal open={open} onOpenChange={setOpen} />;
}

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <AppProvider>
        <ErrorBoundary>
          <BrowserRouter>
            <Routes>
              <Route path="/" element={<Index />} />
              <Route path="/activate" element={<Activation />} />
              <Route path="/login" element={<Login />} />
              <Route path="/setup" element={<Setup />} />
              <Route path="/dashboard" element={<Dashboard />} />
              <Route path="/reports" element={<Reports />} />
              <Route path="/settings" element={<Settings />} />
              <Route path="/workflow" element={<Workflow />} />
              <Route path="/help" element={<Help />} />
              <Route path="/recover" element={<Recover />} />
              {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
              <Route path="*" element={<NotFound />} />
            </Routes>
          </BrowserRouter>
          <GlobalSearchMount />
        </ErrorBoundary>
      </AppProvider>
    </TooltipProvider>
  </QueryClientProvider>
);

createRoot(document.getElementById("root")!).render(<App />);
