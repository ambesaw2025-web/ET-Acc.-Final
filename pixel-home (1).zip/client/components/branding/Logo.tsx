import React from "react";
import clsx from "clsx";

export type LogoProps = {
  size?: number; // pixel size of the circular badge
  className?: string;
  glow?: boolean; // subtle outer glow
  ariaLabel?: string;
};

/**
 * ET circular logo used across the app. Size is in pixels and text scales proportionally.
 */
export function Logo({ size = 80, className, glow = true, ariaLabel = "ET logo" }: LogoProps) {
  const fontSize = Math.round(size * 0.55); // proportional text size
  return (
    <div
      aria-label={ariaLabel}
      className={clsx(
        "rounded-full select-none flex items-center justify-center text-white font-extrabold tracking-[0.06em] leading-none ring-1 ring-slate-700/60",
        glow && "shadow-[0_0_24px_rgba(52,152,219,0.35)]",
        // subtle premium dark gradient fill
        "bg-gradient-to-br from-slate-900 via-slate-800 to-slate-700",
        className
      )}
      style={{ width: size, height: size, fontSize }}
    >
      <span style={{ transform: "translateY(-1px)" }}>ET</span>
    </div>
  );
}

export default Logo;
