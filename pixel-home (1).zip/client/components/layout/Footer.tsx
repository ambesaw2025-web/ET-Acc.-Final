import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { useState } from "react";

export default function Footer() {
  const [open, setOpen] = useState(false);
  return (
    <footer className="fixed bottom-0 left-0 right-0 h-10 bg-white/90 backdrop-blur border-t flex items-center justify-center text-xs text-gray-600 z-40">
      <span>ET Accounting Systems V 1.3 | August 2025 | by&nbsp;</span>
      <button className="text-primary underline-offset-2 hover:underline" onClick={() => setOpen(true)}>Ambes Systems</button>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>About</DialogTitle>
            <DialogDescription>
              Designed by: Andualem T.
              <br />Email: Andex2024@gmail.com
              <br />Addis Ababa, Ethiopia
              <br />All rights reserved - August 2025
            </DialogDescription>
          </DialogHeader>
          <div className="flex justify-end">
            <Button onClick={() => setOpen(false)}>OK</Button>
          </div>
        </DialogContent>
      </Dialog>
    </footer>
  );
}
