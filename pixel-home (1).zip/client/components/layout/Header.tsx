import { Menu } from "lucide-react";
import { useEffect } from "react";
import { Button } from "@/components/ui/button";
import { useSystemDate } from "@/hooks/use-system-date";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { initAntiTamper } from "@/lib/antiTamper";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { useNavigate } from "react-router-dom";

export function AppHeader() {
  const date = useSystemDate();
  useEffect(() => { return initAntiTamper(); }, []);
  const navigate = useNavigate();
  return (
    <div className="sticky top-0 z-40">
      <header className="h-[70px] bg-white/95 backdrop-blur border-b flex items-center px-4 justify-between">
        <Sheet>
          <SheetTrigger asChild>
            <Button variant="ghost" size="icon" aria-label="menu"><Menu /></Button>
          </SheetTrigger>
          <SheetContent side="left" className="w-[300px]">
            <SheetHeader>
              <SheetTitle>Navigation</SheetTitle>
            </SheetHeader>
            <div className="mt-4">
              {[
                { label: "Dashboard", to: "/dashboard" },
                { label: "Accounting (CoA)", to: "/dashboard#coa" },
                { label: "Workflow", to: "/dashboard#workflow" },
                { label: "Reports", to: "/reports" },
                { label: "Settings", to: "/settings" },
                { label: "Help", to: "/help" },
              ].map(i => (
                <button key={i.label} onClick={() => navigate(i.to)} className="w-full text-left px-2 py-2 rounded hover:bg-slate-100">
                  {i.label}
                </button>
              ))}
            </div>
          </SheetContent>
        </Sheet>
        <div className="flex items-center gap-2 font-semibold">
          <span className="text-primary">EasyBooks</span>
          <span className="text-gray-400">|</span>
          <span className="text-gray-600">System Date:</span>
          <span className="text-gray-800">{date}</span>
          <span className="ml-2 text-[10px] text-gray-400">GMT+3 - Ethiopia</span>
        </div>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Avatar className="cursor-pointer"><AvatarFallback>ET</AvatarFallback></Avatar>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuLabel>My Account</DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={() => navigate("/settings")}>Settings</DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={() => navigate("/login")}>Logout</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </header>
      <nav className="h-[60px] bg-white/90 backdrop-blur border-b flex items-center px-4 gap-6">
        {["Home","Workflow","Reports","Search","Settings","Help"].map((item) => (
          <button key={item} className="relative text-sm text-gray-600 hover:text-primary" onClick={() => {
            if (item === "Home") navigate("/dashboard");
            if (item === "Reports") navigate("/reports");
            if (item === "Settings") navigate("/settings");
            if (item === "Workflow") navigate("/workflow");
            if (item === "Help") navigate("/help");
            if (item === "Search") window.dispatchEvent(new CustomEvent("open-search"));
          }}>
            {item}
            {item === "Home" && <span className="absolute -bottom-2 left-0 right-0 h-[2px] bg-primary" />}
          </button>
        ))}
      </nav>
      <div className="h-[30px] bg-slate-50 border-b flex items-center justify-center text-xs text-gray-600">Today's Date: {date} | GMT+3 - Ethiopia (fixed)</div>
    </div>
  );
}
