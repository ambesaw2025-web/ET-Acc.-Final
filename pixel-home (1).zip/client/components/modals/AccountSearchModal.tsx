import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { useApp } from "@/state/app";
import { useMemo, useState } from "react";

export function AccountSearchModal({ open, onOpenChange, onSelect }: { open: boolean; onOpenChange: (v: boolean) => void; onSelect: (id: string) => void; }) {
  const { state } = useApp();
  const [q, setQ] = useState("");
  const [category, setCategory] = useState<string>("");
  const [nature, setNature] = useState<string>("");
  const [status, setStatus] = useState<string>("");

  const filtered = useMemo(() => {
    const kw = q.trim().toLowerCase();
    return state.coa.filter(a => {
      if (kw && !(a.name.toLowerCase().includes(kw) || a.id.includes(q))) return false;
      if (category && a.category !== category) return false;
      if (nature && a.nature !== nature) return false;
      if (status && ((status === 'Active' && !a.active) || (status === 'Inactive' && a.active))) return false;
      return true;
    });
  }, [state.coa, q, category, nature, status]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl p-0 overflow-hidden">
        <div className="bg-white px-4 py-3 border-b flex items-center justify-between">
          <div className="font-semibold">Search Accounts <span className="text-xs text-gray-400">[ACC-SRCH-210]</span></div>
        </div>
        <div className="p-4 space-y-3">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
            <div className="grid gap-1.5"><Label>Keyword</Label><Input placeholder="Name or #" value={q} onChange={(e)=>setQ(e.target.value)} /></div>
            <div className="grid gap-1.5"><Label>Category</Label>
              <select className="h-10 rounded-md border border-input bg-background px-3" value={category} onChange={(e)=>setCategory(e.target.value)}>
                <option value="">All</option>
                {['Asset','Liability','Equity','Income','Expense'].map(c=> <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <div className="grid gap-1.5"><Label>Nature</Label>
              <select className="h-10 rounded-md border border-input bg-background px-3" value={nature} onChange={(e)=>setNature(e.target.value)}>
                <option value="">All</option>
                {['Dr','Cr'].map(n=> <option key={n} value={n}>{n}</option>)}
              </select>
            </div>
            <div className="grid gap-1.5"><Label>Status</Label>
              <select className="h-10 rounded-md border border-input bg-background px-3" value={status} onChange={(e)=>setStatus(e.target.value)}>
                <option value="">All</option>
                <option value="Active">Active</option>
                <option value="Inactive">Inactive</option>
              </select>
            </div>
          </div>
          <div className="grid grid-cols-[160px_1fr_140px_100px_120px] text-sm px-2 py-2 border-b bg-slate-50 rounded-t-md">
            <div>GL Account #</div><div>Name</div><div>Category</div><div>Nature</div><div>Status</div>
          </div>
          <div className="max-h-[360px] overflow-auto divide-y">
            {filtered.map(a => (
              <button key={a.id} onClick={()=>{ onSelect(a.id); onOpenChange(false); }} className="w-full text-left grid grid-cols-[160px_1fr_140px_100px_120px] items-center px-2 py-2 text-sm hover:bg-slate-50">
                <div className="font-mono text-primary">{a.id}</div>
                <div>{a.name}</div>
                <div>{a.category}</div>
                <div>{a.nature}</div>
                <div><span className={`inline-flex items-center gap-1 ${a.active?'text-green-600':'text-red-600'}`}>{a.active? '● Active':'● Inactive'}</span></div>
              </button>
            ))}
            {filtered.length === 0 && (
              <div className="px-2 py-6 text-sm text-gray-500">No accounts match your filters.</div>
            )}
          </div>
          <div className="flex justify-end pt-2"><Button variant="outline" onClick={()=>onOpenChange(false)}>Close</Button></div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
