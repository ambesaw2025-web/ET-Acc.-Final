import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { useApp } from "@/state/app";
import { useMemo, useState } from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { GLForm } from "./GLForm";

export function CoAManager({ open, onOpenChange }: { open: boolean; onOpenChange: (v: boolean) => void }) {
  const { state, setCoa } = useApp();
  const [unlock, setUnlock] = useState(false);
  const [filter, setFilter] = useState("");
  const data = useMemo(()=> state.coa.filter(a => a.name.toLowerCase().includes(filter.toLowerCase()) || a.id.includes(filter)), [state.coa, filter]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-[1000px] p-0 overflow-hidden">
        <div className="bg-gradient-to-r from-slate-800 to-slate-600 text-white px-4 py-3 border-b flex items-center justify-between">
          <div className="font-semibold">Chart of Account Management</div>
          <div className="text-xs opacity-90">System Date: {state.systemDate} • [COA-MGR-110]</div>
        </div>
        <div className="bg-white px-4 py-3 border-b flex items-center justify-between">
          <div className="text-sm text-gray-700">Manage GL accounts; use search and actions.</div>
          <div className="flex gap-2"><Input placeholder="Search" value={filter} onChange={(e)=>setFilter(e.target.value)} className="w-56"/><Button variant="outline" onClick={()=>alert('Reset amounts (current FY)')} >Reset All Amounts</Button><Button variant="destructive" onClick={()=> confirm('Delete all accounts?') && alert('Deleted') }>Delete All Accounts</Button></div>
        </div>
        <div className="px-4 py-2 flex items-center justify-between border-b bg-slate-50">
          <div className="text-sm font-medium">Accounts</div>
          <Button onClick={()=>setUnlock(true)}>Add New GL Account</Button>
        </div>
        <div className="grid grid-cols-[100px_180px_1fr_120px_120px_160px_120px] text-sm px-4 py-2 border-b bg-slate-50">
          <div>S.No.</div><div>GL Account #</div><div>Name</div><div>Category</div><div>Nature</div><div>Running Balance</div><div>Status</div>
        </div>
        <div className="max-h-[420px] overflow-auto divide-y">
          {data.map((a,idx) => (
            <div key={a.id} className="grid grid-cols-[100px_180px_1fr_120px_120px_160px_120px] items-center px-4 py-2 text-sm">
              <div>{idx+1}</div>
              <div><button className="text-primary underline" onClick={()=>setUnlock(true)}>{a.id}</button></div>
              <div>{a.name}</div>
              <div>{a.category}</div>
              <div>{a.nature}</div>
              <div className={(state.abnormalAccounts.includes(a.id)?'text-red-600':'')}>Dr: ETB 0.00 | Cr: ETB 0.00</div>
              <div><span className={`inline-flex items-center gap-1 ${a.active?'text-green-600':'text-red-600'}`}>{a.active? '● Active':'● Inactive'}</span></div>
            </div>
          ))}
        </div>
        {unlock && (
          <div className="p-4 border-t">
            <div className="flex items-center justify-between">
              <div className="font-medium">Add / Edit GL <span className="text-xs text-gray-400">[COA-EDT-120]</span></div>
              <div className="flex gap-2">
                <Button variant="outline" onClick={()=>setUnlock(false)}>Close</Button>
              </div>
            </div>
            <GLForm />
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
