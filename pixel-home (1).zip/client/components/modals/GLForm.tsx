import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { useApp } from "@/state/app";
import { useMemo, useState } from "react";

export function GLForm(){
  const { state, setCoa } = useApp();
  const [name, setName] = useState("");
  const [category, setCategory] = useState<"Asset"|"Liability"|"Equity"|"Income"|"Expense">("Asset");
  const [nature, setNature] = useState<"Dr"|"Cr">("Dr");
  const nextNumber = useMemo(()=>{
    const head = category === 'Asset' ? '1' : category==='Liability' ? '2' : category==='Equity' ? '3' : category==='Income' ? '4' : '5';
    let max = state.coa.filter(a=>a.id.startsWith(head)).map(a=>Number(a.id)).reduce((m,v)=>Math.max(m,v), Number(`${head}0000000`));
    return String(max + 1).padStart(8,'0');
  },[category, state.coa]);

  const save = () => {
    setCoa(prev => [{ id: nextNumber, name, category, nature, active: true }, ...prev]);
    alert('Saved new GL account');
  };

  return (
    <div className="grid grid-cols-2 gap-4 mt-3">
      <div className="grid gap-1.5"><Label>Main Account Name</Label><Input value={name} onChange={(e)=>setName(e.target.value)} /></div>
      <div className="grid gap-1.5"><Label>Number (auto)</Label><Input value={nextNumber} readOnly /></div>
      <div className="grid gap-1.5"><Label>Category</Label>
        <select className="h-10 rounded-md border border-input bg-background px-3" value={category} onChange={(e)=>setCategory(e.target.value as any)}>
          {['Asset','Liability','Equity','Income','Expense'].map(c=> <option key={c} value={c}>{c}</option>)}
        </select>
      </div>
      <div className="grid gap-1.5"><Label>Nature</Label>
        <select className="h-10 rounded-md border border-input bg-background px-3" value={nature} onChange={(e)=>setNature(e.target.value as any)}>
          {['Dr','Cr'].map(n=> <option key={n} value={n}>{n}</option>)}
        </select>
      </div>
      <div className="col-span-2 flex justify-end gap-2 mt-3">
        <Button onClick={save}>Save New GL</Button>
      </div>
    </div>
  );
}
