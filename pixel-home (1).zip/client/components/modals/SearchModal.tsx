import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { useApp } from "@/state/app";
import { useMemo, useState } from "react";

export function SearchModal({ open, onOpenChange }: { open: boolean; onOpenChange: (v:boolean)=>void }){
  const { state } = useApp();
  const [q, setQ] = useState("");
  const tx = useMemo(()=> state.transactions.filter(t=> t.id.includes(q)), [state.transactions, q]);
  const users = useMemo(()=> state.users.filter(u=> u.username.includes(q)), [state.users, q]);
  const accounts = useMemo(()=> state.coa.filter(a=> a.name.toLowerCase().includes(q.toLowerCase()) || a.id.includes(q)), [state.coa, q]);
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl p-0 overflow-hidden">
        <div className="bg-gradient-to-r from-slate-800 to-slate-600 text-white h-11 px-4 flex items-center justify-between">
          <div className="font-medium">Global Search</div>
          <div className="text-xs opacity-90">[SRCH-GLB-200]</div>
        </div>
        <div className="p-4 space-y-3">
          <Input placeholder="Search transactions, users, accounts" value={q} onChange={(e)=>setQ(e.target.value)} />
          <div className="grid grid-cols-3 gap-4 text-sm">
            <div><div className="font-medium">Transactions</div>{tx.slice(0,5).map(t=> <div key={t.id} className="border-b py-1">{t.id}</div>)}</div>
            <div><div className="font-medium">Users</div>{users.slice(0,5).map(u=> <div key={u.id} className="border-b py-1">{u.username}</div>)}</div>
            <div><div className="font-medium">Accounts</div>{accounts.slice(0,5).map(a=> <div key={a.id} className="border-b py-1">{a.id} - {a.name}</div>)}</div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
