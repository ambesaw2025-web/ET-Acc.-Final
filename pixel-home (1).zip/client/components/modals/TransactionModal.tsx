import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useEffect, useMemo, useState } from "react";
import { useApp } from "@/state/app";
import { AccountSearchModal } from "./AccountSearchModal";

export function TransactionModal({ open, onOpenChange }: { open: boolean; onOpenChange: (v: boolean) => void }) {
  const { state, addTransaction, generateRef } = useApp();
  const [ref, setRef] = useState("");
  const [date, setDate] = useState("");
  const [account, setAccount] = useState("");
  const [offset, setOffset] = useState("");
  const [amount, setAmount] = useState<number>(0);
  const [narration, setNarration] = useState("");
  const [error, setError] = useState("");
  const [errorCode, setErrorCode] = useState<string>("");
  const [pickMain, setPickMain] = useState(false);
  const [pickOffset, setPickOffset] = useState(false);

  useEffect(() => {
    if (open) {
      setRef(generateRef("INV"));
      setDate(state.systemDate);
      setAccount("10000001");
      setOffset("40000001");
      setAmount(0);
      setNarration("");
      setError("");
      setErrorCode("");
    }
  }, [open, generateRef, state.systemDate]);

  const acc = useMemo(() => state.coa.find(a => a.id === account), [state.coa, account]);
  const off = useMemo(() => state.coa.find(a => a.id === offset), [state.coa, offset]);

  const submit = (status: "Draft" | "Pending") => {
    setError("");
    setErrorCode("");
    if (!acc) { setError("Main account not found"); setErrorCode("TXN-VLD-002"); return; }
    if (!off) { setError("Offset account not found"); setErrorCode("TXN-VLD-002"); return; }
    if (!acc.active || !off.active) { setError("Inactive account selected"); setErrorCode("TXN-VLD-003"); return; }
    if (account === offset) { setError("Accounts cannot be the same"); setErrorCode("TXN-VLD-004"); return; }
    if (!amount || amount <= 0) { setError("Amount must be greater than zero"); setErrorCode("TXN-VLD-005"); return; }
    if (date !== state.systemDate) { setError("Transaction date must match system date"); setErrorCode("TXN-DATE-006"); return; }
    const lines = [
      { accountId: account, amount: amount, nature: (acc?.nature || "Dr") as any },
      { accountId: offset, amount: amount, nature: ((acc?.nature === "Dr" ? "Cr" : "Dr") as any) },
    ];
    const res = addTransaction({ id: ref, date, makerId: state.session?.user.id || "admin", lines, narration, status });
    if (!res.ok) { setError(res.error || "Error"); setErrorCode("TXN-MFLD-001"); return; }
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl p-0 overflow-hidden">
        <div className="bg-gradient-to-r from-slate-800 to-slate-600 text-white h-11 px-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="text-sm">●</span>
            <div className="font-medium">Transaction Entry • Ref {ref}</div>
          </div>
          <div className="text-xs opacity-90">User: {state.session?.user.username || "guest"} | System Date: {state.systemDate}</div>
        </div>
        <div className="p-6 grid gap-4">
          <div className="grid grid-cols-3 gap-4">
            <div className="grid gap-1.5"><Label>Reference Number</Label><Input value={ref} onChange={(e) => setRef(e.target.value)} readOnly /></div>
            <div className="grid gap-1.5"><Label>Transaction Date</Label><Input type="date" value={date} onChange={(e) => setDate(e.target.value)} /></div>
            <div className="grid gap-1.5"><Label>Currency</Label><Input value="ETB" readOnly /></div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="grid gap-1.5">
              <Label>Main GL Account</Label>
              <div className="flex gap-2">
                <Input placeholder="Account #" value={account} onChange={(e)=>setAccount(e.target.value)} className="w-40" />
                <Button variant="outline" onClick={()=>setPickMain(true)}>Search</Button>
                <Input readOnly value={acc?.name || ""} placeholder="Account name" className="flex-1" />
              </div>
            </div>
            <div className="grid gap-1.5">
              <Label>Offset GL Account</Label>
              <div className="flex gap-2">
                <Input placeholder="Account #" value={offset} onChange={(e)=>setOffset(e.target.value)} className="w-40" />
                <Button variant="outline" onClick={()=>setPickOffset(true)}>Search</Button>
                <Input readOnly value={off?.name || ""} placeholder="Account name" className="flex-1" />
              </div>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="grid gap-1.5"><Label>Amount (ETB)</Label><Input type="number" value={amount} onChange={(e) => setAmount(Number(e.target.value))} /></div>
            <div className="grid gap-1.5"><Label>Account Nature</Label><Input value={acc?.nature === "Dr" ? "Debit" : "Credit"} readOnly /></div>
          </div>
          <div className="grid gap-1.5"><Label>Narration</Label><textarea className="min-h-24 rounded-md border border-input bg-background px-3 py-2" value={narration} onChange={(e) => setNarration(e.target.value)} /></div>
          {error && <div className="text-sm text-red-600">{error} <span className="text-xs text-gray-400">[{errorCode || "TXN-MFLD-001"}]</span></div>}
          <div className="flex justify-end gap-2 pt-2">
            <Button variant="ghost" onClick={() => onOpenChange(false)}>Cancel</Button>
            <Button onClick={() => submit("Draft")}>Save Draft</Button>
            <Button onClick={() => submit("Pending")} className="bg-green-600 hover:bg-green-700">Submit</Button>
          </div>
        </div>
        <AccountSearchModal open={pickMain} onOpenChange={setPickMain} onSelect={(id)=>setAccount(id)} />
        <AccountSearchModal open={pickOffset} onOpenChange={setPickOffset} onSelect={(id)=>setOffset(id)} />
      </DialogContent>
    </Dialog>
  );
}
