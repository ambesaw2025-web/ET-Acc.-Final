import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useState } from "react";
import { UserRecord, hashString, saveUsers, loadUsers, validatePassword } from "@/lib/security";
import { useApp } from "@/state/app";

export function UserManagement({ open, onOpenChange }: { open: boolean; onOpenChange: (v: boolean) => void }) {
  const { state } = useApp();
  const [users, setUsers] = useState<UserRecord[]>(() => loadUsers().filter(u => u.companyId === state.company?.id));
  const [filter, setFilter] = useState("");
  const [editing, setEditing] = useState<UserRecord | null>(null);
  const filtered = users.filter(u => u.username.toLowerCase().includes(filter.toLowerCase()));

  const save = async () => {
    saveUsers(users); setEditing(null);
  };

  const resetPassword = async (u: UserRecord) => {
    const pw = prompt("Enter new password (6+, 2U,2l,1symbol)") || "";
    if (!validatePassword(pw)) return alert("Invalid password");
    const passwordHash = await hashString(pw);
    setUsers(prev => prev.map(x => x.id === u.id ? { ...x, passwordHash } : x));
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-[900px] p-0 overflow-hidden">
        <div className="bg-white p-4 border-b flex items-center justify-between">
          <div className="font-semibold">User Management <span className="text-xs text-gray-400">[USR-MGR-100]</span></div>
          <div className="flex gap-2">
            <Input placeholder="Filter" value={filter} onChange={(e)=>setFilter(e.target.value)} className="w-48"/>
            <Button onClick={() => setEditing({ id: `${Date.now()}`, companyId: state.company!.id, username: "", name: "", role: "Maker", status: "Active", createdAt: new Date().toISOString() })}>Add</Button>
            <Button variant="outline" onClick={() => { saveUsers(users); onOpenChange(false); }}>Export</Button>
          </div>
        </div>
        <div className="grid grid-cols-[1fr_1fr_1fr_1fr_1fr_120px] text-sm px-4 py-2 border-b bg-slate-50">
          <div>Username</div><div>Name</div><div>Role</div><div>Status</div><div>Email</div><div>Actions</div>
        </div>
        <div className="max-h-[420px] overflow-auto divide-y">
          {filtered.map(u => (
            <div key={u.id} className="grid grid-cols-[1fr_1fr_1fr_1fr_1fr_120px] items-center px-4 py-2 text-sm">
              <div>{u.username}</div><div>{u.name}</div><div>{u.role}</div><div className={u.status==='Active'? 'text-green-600':'text-red-600'}>{u.status}</div><div>{u.email||''}</div>
              <div className="flex gap-2">
                <Button size="sm" variant="outline" onClick={()=>setEditing(u)}>Edit</Button>
                <Button size="sm" variant="outline" onClick={()=>resetPassword(u)}>Reset</Button>
                <Button size="sm" variant="outline" onClick={()=>setUsers(prev=>prev.map(x=>x.id===u.id?{...x,status:x.status==='Active'?'Inactive':'Active'}:x))}>{u.status==='Active'?'Disable':'Enable'}</Button>
                {u.status==='Inactive' && <Button size="sm" variant="destructive" onClick={()=>setUsers(prev=>prev.filter(x=>x.id!==u.id))}>Delete</Button>}
              </div>
            </div>
          ))}
        </div>
        {editing && (
          <div className="p-4 border-t grid grid-cols-2 gap-4">
            <div className="grid gap-1.5"><Label>Username</Label><Input value={editing.username} onChange={(e)=>setEditing({...editing, username:e.target.value})}/></div>
            <div className="grid gap-1.5"><Label>Name</Label><Input value={editing.name} onChange={(e)=>setEditing({...editing, name:e.target.value})}/></div>
            <div className="grid gap-1.5"><Label>Email</Label><Input value={editing.email||''} onChange={(e)=>setEditing({...editing, email:e.target.value})}/></div>
            <div className="grid gap-1.5"><Label>Role</Label>
              <select className="h-10 rounded-md border border-input bg-background px-3" value={editing.role} onChange={(e)=>setEditing({...editing, role:e.target.value as any})}>
                {["Maker","Checker","Authorizer","Custom Admin","Default Admin"].map(r=> <option key={r} value={r}>{r}</option>)}
              </select>
            </div>
            <div className="grid gap-1.5"><Label>Status</Label>
              <select className="h-10 rounded-md border border-input bg-background px-3" value={editing.status} onChange={(e)=>setEditing({...editing, status:e.target.value as any})}>
                {["Active","Inactive"].map(r=> <option key={r} value={r}>{r}</option>)}
              </select>
            </div>
            <div className="col-span-2 flex justify-end gap-2">
              <Button variant="ghost" onClick={()=>setEditing(null)}>Cancel</Button>
              <Button onClick={()=>{ setUsers(prev=>{const exists=prev.some(x=>x.id===editing.id); return exists? prev.map(x=>x.id===editing.id?editing:x):[editing,...prev];}); save(); }}>Save</Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
