import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { useApp } from "@/state/app";

export function WorkflowModal({ open, onOpenChange, txId }: { open: boolean; onOpenChange: (v: boolean) => void; txId?: string }) {
  const { state, setTransactionsStatus } = useApp();
  const tx = state.transactions.find(t => t.id === txId);
  if (!tx) return null as any;
  const maker = tx.makerId;
  const user = state.session?.user.id;
  const role = state.session?.user.role;
  const canAuthOwn = false;
  const canAuthorize = !!user && maker !== user && ["Checker","Authorizer","Custom Admin","Default Admin"].includes(role as any);
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <div className="font-semibold">Workflow <span className="text-xs text-gray-400">[WFL-CTX-130]</span></div>
        <div className="text-sm">Status: {tx.status}</div>
        <div className="flex justify-end gap-2 pt-3">
          {tx.status === 'Pending' && (
            <>
              <Button variant="destructive" onClick={()=>{ setTransactionsStatus(tx.id,'Rejected', state.session?.user.id); onOpenChange(false); }}>Reject</Button>
              <Button disabled={!canAuthorize || !canAuthOwn && maker===user} onClick={()=>{ setTransactionsStatus(tx.id,'Approved', state.session?.user.id); onOpenChange(false); }}>Authorize</Button>
            </>
          )}
          {tx.status === 'Approved' && (
            <Button onClick={()=>{ setTransactionsStatus(tx.id,'Reversed', state.session?.user.id); onOpenChange(false); }}>Reverse</Button>
          )}
          {(tx.status === 'Rejected' || tx.status==='Reversed') && (
            <Button onClick={()=>onOpenChange(false)}>Close</Button>
          )}
        </div>
        <div className="text-xs text-gray-500 pt-2">Maker: {tx.makerId} | Checker: {tx.checkerId || '-'} | Ref: {tx.id}</div>
      </DialogContent>
    </Dialog>
  );
}
