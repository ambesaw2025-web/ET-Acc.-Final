import React from "react";

export class ErrorBoundary extends React.Component<{ children: React.ReactNode }, { error?: Error }>{
  constructor(props: any){ super(props); this.state = {}; }
  static getDerivedStateFromError(error: Error){ return { error }; }
  componentDidCatch(err: Error){ console.error("App Error", err); }
  render(){
    if (this.state.error){
      return (
        <div className="min-h-screen flex items-center justify-center bg-slate-50 p-6">
          <div className="max-w-lg w-full bg-white border rounded-xl shadow p-6 text-center">
            <h2 className="text-xl font-semibold mb-2">Something went wrong</h2>
            <p className="text-sm text-gray-600">Please refresh or contact support. Error: {this.state.error.message}</p>
            <div className="mt-4 text-xs text-gray-400">[SYS-ERR-500]</div>
          </div>
        </div>
      );
    }
    return this.props.children as any;
  }
}
