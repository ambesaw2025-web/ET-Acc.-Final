import { useEffect, useState } from "react";

export function useSystemDate() {
  const [now, setNow] = useState<string>("");
  useEffect(() => {
    const fmt = () => {
      const date = new Date();
      const tz = "Africa/Addis_Ababa";
      const formatted = new Intl.DateTimeFormat("en-GB", {
        weekday: "long",
        day: "2-digit",
        month: "long",
        year: "numeric",
        timeZone: tz,
      }).format(date);
      setNow(formatted);
    };
    fmt();
    const t = setInterval(fmt, 30_000);
    return () => clearInterval(t);
  }, []);
  return now;
}
