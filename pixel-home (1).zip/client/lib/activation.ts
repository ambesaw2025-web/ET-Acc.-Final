import { hashString } from "./security";

function b64(s: string){ try { return atob(s); } catch { return ""; } }

const SALT_PARTS = ["I0FNQkVTI", "19TQUxUXzIwMjUj"];
const MASTER_HASH_B64 = "ZjExMzAyYmU2N2VlNDJmZTk2MDMzZjU0ZjA1N2JhMTk4ZTY0YjVhOTI2ZDYyYzI0NzM0YjA2NjQyN2VjYTUxOQ=="; // sha256(salt+code) precomputed, obfuscated

export async function deviceFingerprint(): Promise<string> {
  const nav = window.navigator;
  const key = [nav.platform, nav.language, nav.hardwareConcurrency, nav.userAgent].join("|");
  let guid = localStorage.getItem("et_guid");
  if (!guid){ guid = crypto.randomUUID(); localStorage.setItem("et_guid", guid); }
  return await hashString(key + "|" + guid);
}

export async function validateKey(input: string): Promise<{ok: boolean; cert?: string; error?: string}> {
  const cleaned = input.replace(/[^A-Za-z0-9-]/g, '').toUpperCase();
  if (!/^([A-Z0-9]{4}-){4}[A-Z0-9]{4,5}$/.test(cleaned)) return { ok: false, error: "Invalid format" };
  const salt = b64(SALT_PARTS.join(''));
  const calc = await hashString(salt + cleaned);
  const master = b64(MASTER_HASH_B64);
  if (calc !== master) return { ok: false, error: "License not recognized" };
  const fp = await deviceFingerprint();
  const cert = btoa(JSON.stringify({ v: 1, ok: true, fp, ts: Date.now() }));
  return { ok: true, cert };
}

export function hasValidCertificate(): boolean {
  const raw = localStorage.getItem("et_license_cert");
  if (!raw) return false;
  try {
    const data = JSON.parse(atob(raw));
    return !!data?.ok && typeof data?.fp === 'string';
  } catch { return false; }
}
