import { hashString } from "@/lib/security";

/**
 * Lightweight client-side tamper deterrents.
 * NOTE: Client-side protections are bypassable; use server-side checks for real security.
 */
export function initAntiTamper() {
  // Skip in dev, localhost, or when inside an iframe (preview environments)
  const isDev = import.meta?.env?.MODE !== "production";
  const isLocal = /^(localhost|127\.|0\.0\.0\.0)/.test(location.hostname);
  const isFramed = window.top !== window.self;
  if (isDev || isLocal || isFramed) return () => {};

  const onContext = (e: Event) => e.preventDefault();
  const onKey = (e: KeyboardEvent) => {
    const blocked = (
      e.key === "F12" ||
      (e.ctrlKey && e.shiftKey && ["I","J","C"].includes(e.key.toUpperCase())) ||
      (e.ctrlKey && e.key.toUpperCase() === "U")
    );
    if (blocked) { e.preventDefault(); e.stopPropagation(); }
  };

  document.addEventListener("contextmenu", onContext);
  document.addEventListener("keydown", onKey, true);

  // Simple devtools/open-window heuristic
  let tripped = false;
  const iv = window.setInterval(() => {
    const open = (window.outerWidth - window.innerWidth > 160) || (window.outerHeight - window.innerHeight > 160);
    if (open && !tripped) {
      tripped = true;
      localStorage.setItem("et_anti_tamper_lock", "1");
      // Redirect away from sensitive screens
      location.replace("/");
    }
  }, 1500);

  // Create a basic device fingerprint for anomaly detection
  const fpBase = [navigator.userAgent, navigator.language, screen.width + "x" + screen.height, Intl.DateTimeFormat().resolvedOptions().timeZone].join("|");
  hashString(fpBase).then((h) => localStorage.setItem("et_fp", h)).catch(() => {});

  return () => {
    document.removeEventListener("contextmenu", onContext);
    document.removeEventListener("keydown", onKey, true);
    window.clearInterval(iv);
  };
}
