export type ErrorCode = string;
export const ErrorCodes: Record<string, string> = {
  "GAT-CFM-101": "Gateway new company confirmation",
  "STP-CPL-200": "Setup completed successfully",
  "TXN-MFLD-001": "Transaction validation error",
  "TXN-VLD-002": "Invalid GL account or amount",
  "TXN-VLD-003": "Inactive account selected",
  "TXN-VLD-004": "Same account used for both sides",
  "TXN-VLD-005": "Amount must be greater than zero",
  "TXN-DATE-006": "Transaction date does not match system date",
  "USR-VALD-002": "User form validation error",
  "USR-RST-003": "Password/PIN reset confirmation",
  "COA-ABNR-004": "Abnormal GL balance detected",
  "EOD-BLCK-005": "End of day blocked",
  "SEC-SSN-401": "Session timed out",
  "COA-NBUS-201": "Default chart seeded by nature of business",
  "SET-CNF-301": "Settings change confirmation",
};
