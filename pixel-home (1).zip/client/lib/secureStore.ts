const enc = new TextEncoder();
const dec = new TextDecoder();

function getCertData(): { fp: string } | null {
  const raw = localStorage.getItem("et_license_cert");
  if (!raw) return null;
  try { return JSON.parse(atob(raw)); } catch { return null; }
}

async function getKey(): Promise<CryptoKey> {
  const cert = getCertData();
  let guid = localStorage.getItem("et_guid");
  if (!guid) { guid = crypto.randomUUID(); localStorage.setItem("et_guid", guid); }
  const material = await crypto.subtle.digest("SHA-256", enc.encode((cert?.fp || "anon") + "|" + guid));
  return crypto.subtle.importKey("raw", material, { name: "AES-GCM" }, false, ["encrypt", "decrypt"]);
}

function toB64(arr: ArrayBuffer){ return btoa(String.fromCharCode(...new Uint8Array(arr))); }
function fromB64(b64: string){ return Uint8Array.from(atob(b64), c => c.charCodeAt(0)); }

export async function secureSet(key: string, value: unknown){
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const plain = enc.encode(JSON.stringify(value));
  const cipher = await crypto.subtle.encrypt({ name: "AES-GCM", iv }, await getKey(), plain);
  const payload = `${toB64(iv)}.${toB64(cipher)}`;
  localStorage.setItem(key, payload);
}

export async function secureGet<T = unknown>(key: string): Promise<T | null>{
  const raw = localStorage.getItem(key);
  if (!raw) return null;
  const [ivB64, dataB64] = raw.split(".");
  if (!ivB64 || !dataB64) return null;
  try{
    const iv = fromB64(ivB64);
    const data = fromB64(dataB64);
    const plain = await crypto.subtle.decrypt({ name: "AES-GCM", iv }, await getKey(), data);
    return JSON.parse(dec.decode(plain)) as T;
  } catch { return null; }
}

export function secureRemove(key: string){ localStorage.removeItem(key); }
