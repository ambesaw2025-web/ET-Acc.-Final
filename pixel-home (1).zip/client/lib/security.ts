export function validatePin(pin: string): boolean {
  if (!/^\d{4}$/.test(pin)) return false;
  const seq = "0123456789";
  const revSeq = "9876543210";
  if (/(\d)\1{3}/.test(pin)) return false;
  if (seq.includes(pin) || revSeq.includes(pin)) return false;
  return true;
}

export function validatePassword(pw: string): boolean {
  if (pw.length < 6) return false;
  const upper = (pw.match(/[A-Z]/g) || []).length >= 2;
  const lower = (pw.match(/[a-z]/g) || []).length >= 2;
  const symbol = /[^A-Za-z0-9]/.test(pw);
  return upper && lower && symbol;
}

export async function hashString(input: string): Promise<string> {
  const enc = new TextEncoder();
  const data = enc.encode(input);
  const digest = await crypto.subtle.digest({ name: "SHA-256" }, data);
  const arr = Array.from(new Uint8Array(digest));
  return arr.map((b) => b.toString(16).padStart(2, "0")).join("");
}

export function genCompanyId(name: string, existing: string[] = []): string {
  const letters = name.replace(/[^A-Za-z]/g, "").toUpperCase().slice(0, 3).padEnd(3, "X");
  let num = 1;
  let id = "";
  do {
    id = `${letters}${String(num).padStart(2, "0")}`;
    num++;
  } while (existing.includes(id));
  return id;
}

export type NatureOfBusiness =
  | "Sole Proprietor"
  | "Share Company"
  | "Private Limited Company"
  | "Partnership"
  | "NGO"
  | "Other";

export type AccountingMethod = "Cash" | "Accrual";

export interface Company {
  id: string;
  name: string;
  address?: string;
  contact?: string;
  taxId?: string;
  nature: NatureOfBusiness;
  fiscalStart: string;
  fiscalEnd: string;
  firstMonth: number;
  method: AccountingMethod;
  createdAt: string;
}

export interface UserRecord {
  id: string;
  companyId: string;
  username: string;
  name: string;
  email?: string;
  role: "Default Admin" | "Custom Admin" | "Authorizer" | "Checker" | "Maker";
  status: "Active" | "Inactive";
  pinHash?: string;
  passwordHash?: string;
  security?: { q1: string; a1Hash: string; q2: string; a2Hash: string };
  createdAt: string;
}

import { secureGet, secureSet } from "./secureStore";

export function loadCompany(): Company | null {
  const raw = localStorage.getItem("et_company");
  return raw ? (JSON.parse(raw) as Company) : null;
}

export async function saveCompany(c: Company) {
  // store encrypted (primary)
  await secureSet("et_company_secure", c);
  // keep plain for backward compat until full hydration is added
  localStorage.setItem("et_company", JSON.stringify(c));
}

export function loadUsers(): UserRecord[] {
  const raw = localStorage.getItem("et_users");
  return raw ? (JSON.parse(raw) as UserRecord[]) : [];
}

export async function saveUsers(list: UserRecord[]) {
  await secureSet("et_users_secure", list);
  localStorage.setItem("et_users", JSON.stringify(list));
}

export async function secureLoadCompany(): Promise<Company | null> {
  return (await secureGet<Company>("et_company_secure")) || loadCompany();
}

export async function secureLoadUsers(): Promise<UserRecord[]> {
  return (await secureGet<UserRecord[]>("et_users_secure")) || loadUsers();
}

export function findAdminByCompany(companyId: string): UserRecord | undefined {
  return loadUsers().find(u => u.companyId === companyId && u.role === "Default Admin");
}

export function findUser(companyId: string, username: string): UserRecord | undefined {
  return loadUsers().find(u => u.companyId === companyId && u.username.toLowerCase() === username.toLowerCase());
}

export async function changeAdminPin(companyId: string, newPin: string): Promise<boolean> {
  if (!validatePin(newPin)) return false;
  const list = loadUsers();
  const idx = list.findIndex(u => u.companyId === companyId && u.role === "Default Admin");
  if (idx < 0) return false;
  list[idx].pinHash = await hashString(newPin);
  saveUsers(list);
  return true;
}

export async function changeUserPassword(companyId: string, username: string, newPw: string): Promise<boolean> {
  if (!validatePassword(newPw)) return false;
  const list = loadUsers();
  const idx = list.findIndex(u => u.companyId === companyId && u.username.toLowerCase() === username.toLowerCase());
  if (idx < 0) return false;
  list[idx].passwordHash = await hashString(newPw);
  saveUsers(list);
  return true;
}
