import { useEffect, useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useNavigate } from "react-router-dom";
import { hasValidCertificate, validateKey } from "@/lib/activation";
import Logo from "@/components/branding/Logo";
import { initAntiTamper } from "@/lib/antiTamper";
import Footer from "@/components/layout/Footer";

export default function Activation() {
  const navigate = useNavigate();
  const [code, setCode] = useState("");
  const [status, setStatus] = useState<string>("");
  const [busy, setBusy] = useState(false);

  useEffect(()=>{
    const cleanup = initAntiTamper();
    if (hasValidCertificate()) {
      const hasCompany = !!localStorage.getItem("et_company");
      navigate(hasCompany? "/login" : "/setup");
    }
    return cleanup;
  },[navigate]);

  const submit = async () => {
    setBusy(true); setStatus("");
    const res = await validateKey(code);
    if (!res.ok) { setStatus(res.error || "Activation failed [ACT-ERR-901]"); setBusy(false); return; }
    localStorage.setItem("et_license_cert", res.cert!);
    setStatus("Activated successfully. Redirecting...");
    setTimeout(()=>{
      const hasCompany = !!localStorage.getItem("et_company");
      navigate(hasCompany? "/login" : "/setup");
    }, 800);
  };

  return (
    <div className="min-h-screen w-full geo-pattern flex items-center justify-center p-6">
      <Card className="w-[500px] p-10 rounded-[16px] shadow-[0_20px_40px_rgba(0,0,0,0.15)] space-y-6">
        <Logo size={80} className="mx-auto" />
        <div className="text-center space-y-1">
          <h2 className="text-[28px] font-semibold text-[#2c3e50] heading-blur">Activate Your License</h2>
          <p className="text-[16px] text-[#7f8c8d]">To begin your journey with ET Accounting Systems, please enter your activation code</p>
        </div>
        <div className="grid gap-2">
          <Label>Activation Code</Label>
          <Input className="h-14 border-2 rounded-lg text-center font-mono text-[16px] focus-visible:ring-0 focus-visible:border-[#3498db] focus-visible:outline-none shadow-[0_0_0_3px_rgba(52,152,219,0.10)]" placeholder="Enter activation code (e.g., AMBES-519E-118TA-951C-51SY)" value={code} onChange={(e)=>setCode(e.target.value)} />
        </div>
        {status && (
          <div className={`text-sm text-center rounded p-2 flex items-center justify-center gap-2 ${status.toLowerCase().includes('success')?'bg-green-50 text-green-700':'bg-red-50 text-red-700'}`}>
            <span className={`h-4 w-4 rounded-full ${status.toLowerCase().includes('success')?'bg-green-500':'bg-red-500'}`}></span>
            {status}
          </div>
        )}
        {busy && (
          <div className="text-sm text-center text-gray-600 flex items-center justify-center gap-2">
            <svg className="h-4 w-4 animate-spin" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" stroke="#3498db" strokeWidth="3" fill="none"/></svg>
            Verifying license...
          </div>
        )}
        <Button onClick={submit} disabled={busy} className="w-full h-14 bg-[linear-gradient(135deg,#3498db,#2980b9)] text-white hover:scale-[1.02] hover:brightness-95">Activate & Continue</Button>
        <div className="text-[14px] text-[#95a5a6] text-center">Need help? <a className="text-[#3498db] underline-offset-2 hover:underline" href="mailto:support@ambes.com">support@ambes.com</a></div>
      </Card>
      <Footer />
    </div>
  );
}
