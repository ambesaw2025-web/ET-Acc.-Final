import { AppHeader } from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import { Card } from "@/components/ui/card";
import { ChartContainer, ChartLegend, ChartLegendContent, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart";
import { Bar, BarChart, Cell, Pie, PieChart, XAxis, YAxis } from "recharts";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { TransactionModal } from "@/components/modals/TransactionModal";
import { UserManagement } from "@/components/modals/UserManagement";
import { CoAManager } from "@/components/modals/CoAManager";
import { WorkflowModal } from "@/components/modals/WorkflowModal";
import { useApp } from "@/state/app";

const pieData = [
  { name: "Income", value: 640000, fill: "var(--color-income)" },
  { name: "Expenses", value: 420000, fill: "var(--color-expenses)" },
];
const barData = Array.from({ length: 12 }).map((_, i) => ({
  month: new Intl.DateTimeFormat("en", { month: "short" }).format(new Date(2025, i, 1)),
  value: Math.round(20000 + Math.random() * 80000),
}));

export default function Dashboard() {
  const [txnOpen, setTxnOpen] = useState(false);
  const [usersOpen, setUsersOpen] = useState(false);
  const [coaOpen, setCoaOpen] = useState(false);
  const [workflowOpen, setWorkflowOpen] = useState<string | undefined>(undefined);
  const { state } = useApp();
  return (
    <div className="min-h-screen geo-pattern">
      <AppHeader />
      <main className="container py-6"><div className="bg-white rounded-xl border border-slate-200 ring-1 ring-black/5 shadow-sm p-6 space-y-6">
        <section className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {[
            { label: "Total Income", value: 640000 },
            { label: "Expenses", value: 420000 },
            { label: "Net Profit", value: 220000 },
            { label: "Cash Flow", value: 180000 },
          ].map((m) => (
            <Card key={m.label} className="p-4">
              <div className="text-xs text-gray-500">{m.label}</div>
              <div className="text-2xl font-bold">ETB {m.value.toLocaleString()}</div>
            </Card>
          ))}
        </section>

        <section className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card className="p-4">
            <h3 className="font-semibold mb-2">Income vs Expenses</h3>
            <ChartContainer config={{ income: { color: "hsl(var(--primary))" }, expenses: { color: "hsl(var(--destructive))" } }}>
              <PieChart>
                <ChartTooltip content={<ChartTooltipContent />} />
                <Pie data={pieData} dataKey="value" nameKey="name" cx="50%" cy="50%" innerRadius={60} outerRadius={90} strokeWidth={4}>
                  {pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={index === 0 ? "hsl(var(--primary))" : "hsl(var(--destructive))"} />
                  ))}
                </Pie>
                <ChartLegend content={<ChartLegendContent />} />
              </PieChart>
            </ChartContainer>
          </Card>

          <Card className="p-4">
            <h3 className="font-semibold mb-2">Monthly Performance</h3>
            <ChartContainer config={{ value: { color: "hsl(var(--accent))" } }}>
              <BarChart data={barData}>
                <XAxis dataKey="month" stroke="#94a3b8" />
                <YAxis stroke="#94a3b8" />
                <ChartTooltip content={<ChartTooltipContent />} />
                <Bar dataKey="value" fill="hsl(var(--accent))" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ChartContainer>
          </Card>
        </section>

        <section className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {[{label:"Record Sale",action:() => setTxnOpen(true)},{label:"Add Client"},{label:"Receive Payment",action:() => setTxnOpen(true)},{label:"Create Purchase"},{label:"Post Journal",action:() => setTxnOpen(true)},{label:"View CoA"}].map((q) => (
            <Card key={q.label} className="p-6 h-[120px] flex items-center justify-center hover:shadow-md transition-shadow cursor-pointer" onClick={q.action as any}>
              <div className="text-sm font-medium">{q.label}</div>
            </Card>
          ))}
        </section>

        <section className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card className="p-4">
            <h3 className="font-semibold mb-2">Recent Activity & Alerts</h3>
            <div className="space-y-2 max-h-[240px] overflow-auto">
              {state.transactions.slice(0,7).map((t) => (
                <div key={t.id} className="flex items-center justify-between text-sm border-b py-2">
                  <div>
                    <div className="font-mono">{t.id}</div>
                    <div className="text-xs text-gray-500">{t.narration || "Transaction"} · {t.status}</div>
                  </div>
                  <div className="text-xs text-gray-600">{t.date}</div>
                </div>
              ))}
              {state.abnormalAccounts.length > 0 && (
                <div className="text-red-700 bg-red-50 border border-red-200 rounded p-2 text-sm">System Alert: Abnormal GL Balances detected.</div>
              )}
            </div>
          </Card>
          <Card className="p-4 flex items-center justify-between">
            <div>
              <h3 className="font-semibold mb-1">Management</h3>
              <p className="text-sm text-gray-600">Users, CoA, and Workflow actions.</p>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" onClick={()=>setUsersOpen(true)}>Users</Button>
              <Button variant="outline" onClick={()=>setCoaOpen(true)}>CoA</Button>
              <Button onClick={()=>setWorkflowOpen(state.transactions[0]?.id)} disabled={!state.transactions.length}>Workflow</Button>
            </div>
          </Card>
        </section>
      </div></main>
      <Footer />
      <TransactionModal open={txnOpen} onOpenChange={setTxnOpen} />
      <UserManagement open={usersOpen} onOpenChange={setUsersOpen} />
      <CoAManager open={coaOpen} onOpenChange={setCoaOpen} />
      <WorkflowModal open={!!workflowOpen} onOpenChange={()=>setWorkflowOpen(undefined)} txId={workflowOpen} />
    </div>
  );
}
