import { AppHeader } from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";

export default function Help(){
  return (
    <div className="min-h-screen bg-slate-50">
      <AppHeader />
      <main className="container py-6"><div className="bg-white rounded-xl border border-slate-200 ring-1 ring-black/5 shadow-sm p-6">
        <h3 className="font-semibold mb-2">Help & Documentation</h3>
        <p className="text-sm text-gray-600">Contact support at Andex2024@gmail.com. Refer to Reports for audit trails and Advice generation.</p>
      </div></main>
      <Footer />
    </div>
  );
}
