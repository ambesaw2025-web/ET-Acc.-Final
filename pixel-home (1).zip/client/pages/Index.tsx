import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useNavigate } from "react-router-dom";
import Logo from "@/components/branding/Logo";
import Footer from "@/components/layout/Footer";

export default function Index() {
  const navigate = useNavigate();
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const [companyExists, setCompanyExists] = useState<boolean>(false);
  const [showLanding, setShowLanding] = useState<boolean>(true);

  useEffect(() => {
    const hasCert = !!localStorage.getItem("et_license_cert");
    if (!hasCert) { navigate("/activate"); return; }
    const hasCompany = !!localStorage.getItem("et_company");
    setCompanyExists(hasCompany);
    const seen = localStorage.getItem("et_landing_seen") === "1";
    if (seen) {
      navigate(hasCompany ? "/login" : "/setup");
    } else {
      setShowLanding(true);
    }
  }, [navigate]);

  const handleSetupNew = () => setShowResetConfirm(true);

  const confirmNewCompany = () => {
    localStorage.removeItem("et_company");
    localStorage.removeItem("et_users");
    localStorage.setItem("et_landing_seen","1");
    navigate("/setup");
  };

  return (
    <div className="min-h-screen w-full geo-pattern p-6">
      <header className="container flex items-center justify-between">
        <button onClick={()=>window.location.reload()} className="flex items-center gap-2">
          <Logo size={56} />
        </button>
        <Button variant="outline" onClick={()=>{ localStorage.setItem("et_landing_seen","1"); navigate('/login'); }}>Login to Existing Company</Button>
      </header>
      <main className="container mt-10">
        <section className="text-center mb-10">
          <h1 className="text-[36px] font-bold text-[#2c3e50] heading-blur">Welcome to ET Accounting Systems</h1>
          <p className="text-[18px] text-[#7f8c8d]">Your complete financial management solution</p>
        </section>
        <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-10">
          {["Secure Double-Entry","Role-Based Access","Real-time Reports","Ethiopian Standards"].map((t,i)=> (
            <div key={i} className="h-[120px] p-6 bg-white border border-[#e2e8f0] rounded-[12px] hover:shadow-md hover:border-[#3498db] transition">
              <div className="flex items-start gap-3"><span className="text-green-600">✔</span><div><div className="text-[16px] text-[#2c3e50] font-semibold">{t}</div><div className="text-[14px] text-[#7f8c8d]">Configured out of the box.</div></div></div>
            </div>
          ))}
        </section>
        <section className="rounded-[12px] p-6 bg-[#fef9e7] border border-[#f1c40f]/40 text-center">
          <h3 className="text-[24px] text-[#2c3e50] font-semibold mb-1">Ready to Get Started?</h3>
          <p className="text-[16px] text-[#7f8c8d] mb-4">Setup your company in just a few minutes</p>
          <Button className="h-14 w-full max-w-xl mx-auto bg-[#f1c40f] text-[#2c3e50] hover:bg-[#f39c12]" onClick={()=>{ localStorage.setItem("et_landing_seen","1"); navigate('/setup'); }}>Setup Your Company Now</Button>
        </section>
      </main>
      <Footer />

      <Dialog open={showResetConfirm} onOpenChange={setShowResetConfirm}>
        <DialogContent className="max-w-[520px]">
          <DialogHeader>
            <DialogTitle>
              Confirm New Company
              <span className="ml-2 text-xs text-gray-400">[GAT-CFM-101]</span>
            </DialogTitle>
            <DialogDescription>
              This will erase any existing company data from this device. Are you sure you want to continue?
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-2">
            <Label htmlFor="confirm">Type CONFIRM to proceed</Label>
            <Input id="confirm" placeholder="CONFIRM" onChange={(e) => {
              const ok = e.currentTarget.value.trim().toUpperCase() === "CONFIRM";
              (document.getElementById("confirm-new-btn") as HTMLButtonElement | null)?.toggleAttribute("disabled", !ok);
            }} />
          </div>
          <DialogFooter className="gap-2">
            <Button variant="ghost" onClick={() => setShowResetConfirm(false)}>Cancel</Button>
            <Button id="confirm-new-btn" disabled onClick={confirmNewCompany} className="bg-red-600 hover:bg-red-700">Erase & Start Setup</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
