import { useEffect, useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group";
import { InputOTP, InputOTPGroup, InputOTPSlot } from "@/components/ui/input-otp";
import { z } from "zod";
import { useNavigate } from "react-router-dom";
import Footer from "@/components/layout/Footer";
import { initAntiTamper } from "@/lib/antiTamper";
import { hashString, loadCompany, loadUsers } from "@/lib/security";
import { useApp } from "@/state/app";

const companyIdSchema = z.string().regex(/^[A-Z]{3}\d{2}$/);

export default function Login() {
  const navigate = useNavigate();
  const { login } = useApp();
  const [type, setType] = useState<"Admin" | "User" | "Custom Admin">("Admin");
  const [companyId, setCompanyId] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [pin, setPin] = useState("");
  const [error, setError] = useState<string>("");
  const company = useMemo(() => loadCompany(), []);

  useEffect(() => {
    const cleanup = initAntiTamper();
    if (!company) navigate("/setup");
    return cleanup;
  }, [company, navigate]);

  const onSubmit = async () => {
    setError("");
    const cid = companyId.trim().toUpperCase();
    if (!companyIdSchema.safeParse(cid).success) {
      setError("Invalid credentials");
      return;
    }
    const keyUser = type === "Admin" ? "admin" : username.trim().toLowerCase() || "user";
    const lockKey = `et_lock_${cid}_${type}_${keyUser}`;
    const raw = localStorage.getItem(lockKey);
    if (raw) {
      const lock = JSON.parse(raw) as { count: number; until?: number };
      if (lock.until && Date.now() < lock.until) {
        setError("Invalid credentials");
        return;
      }
    }
    const users = loadUsers().filter((u) => u.companyId === cid);
    const fail = () => {
      const current = raw ? (JSON.parse(raw) as { count: number; until?: number }) : { count: 0 };
      const next = { ...current, count: (current.count || 0) + 1 } as { count: number; until?: number };
      if (next.count >= 5) {
        next.until = Date.now() + 15 * 60 * 1000;
      }
      localStorage.setItem(lockKey, JSON.stringify(next));
      setError("Invalid credentials");
    };
    if (type === "Admin") {
      const admin = users.find((u) => u.role === "Default Admin" && u.status === "Active");
      if (!admin) return fail();
      const p = await hashString(pin);
      if (p !== admin.pinHash) return fail();
      localStorage.removeItem(lockKey);
      login(admin);
      navigate("/dashboard");
      return;
    }
    const user = users.find((u) => u.username.toLowerCase() === username.trim().toLowerCase());
    if (!user) return fail();
    const ph = await hashString(password);
    if (ph !== user.passwordHash) return fail();
    localStorage.removeItem(lockKey);
    login(user);
    navigate("/dashboard");
  };

  return (
    <div className="min-h-screen w-full geo-pattern flex items-center justify-center p-6">
      <div className="w-[500px] h-[550px] max-w-full bg-white rounded-xl shadow-xl border border-slate-200 ring-1 ring-black/5 p-8">
        <h1 className="text-xl font-bold text-center heading-blur">Login</h1>
        <p className="text-center text-sm text-gray-500 mt-1">{company?.name ? `Company: ${company.name}` : ""}</p>
        <div className="mt-6 grid gap-4">
          <div className="grid gap-2">
            <Label htmlFor="companyId">Company ID</Label>
            <Input id="companyId" placeholder="ABC01" value={companyId} onChange={(e) => setCompanyId(e.target.value.toUpperCase())} />
          </div>
          <div className="grid gap-2">
            <Label>Login Type</Label>
            <ToggleGroup type="single" value={type} onValueChange={(v) => v && setType(v as any)} className="justify-center">
              <ToggleGroupItem value="Admin">Admin</ToggleGroupItem>
              <ToggleGroupItem value="User">User</ToggleGroupItem>
              <ToggleGroupItem value="Custom Admin">Custom Admin</ToggleGroupItem>
            </ToggleGroup>
          </div>
          {type === "Admin" ? (
            <div className="grid gap-2">
              <Label>4-Digit PIN</Label>
              <InputOTP maxLength={4} value={pin} onChange={setPin}>
                <InputOTPGroup>
                  <InputOTPSlot index={0} />
                  <InputOTPSlot index={1} />
                  <InputOTPSlot index={2} />
                  <InputOTPSlot index={3} />
                </InputOTPGroup>
              </InputOTP>
              <div className="text-xs text-right text-primary hover:underline cursor-pointer" onClick={()=>navigate('/recover')}>Forgot PIN?</div>
            </div>
          ) : (
            <>
              <div className="grid gap-2">
                <Label>Username</Label>
                <Input value={username} onChange={(e) => setUsername(e.target.value)} />
              </div>
              <div className="grid gap-2">
                <Label>Password</Label>
                <Input type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
                <div className="text-xs text-right text-primary hover:underline cursor-pointer" onClick={()=>navigate('/recover')}>Forgot Password?</div>
              </div>
            </>
          )}
          {error && (
            <div className="text-red-600 text-sm bg-red-50 border border-red-200 rounded p-2" role="alert">
              Invalid credentials
            </div>
          )}
          <Button className="mt-2" onClick={onSubmit}>Login</Button>
        </div>
      </div>
      <Footer />
    </div>
  );
}
