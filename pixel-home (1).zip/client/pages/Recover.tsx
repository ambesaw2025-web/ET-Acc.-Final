import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import Footer from "@/components/layout/Footer";
import { useState } from "react";
import { changeAdminPin, changeUserPassword, findAdminByCompany, findUser, hashString, validatePassword, validatePin } from "@/lib/security";

export default function Recover(){
  const [mode, setMode] = useState<'PIN'|'PASSWORD'>('PIN');
  const [companyId, setCompanyId] = useState('');
  const [username, setUsername] = useState('');
  const [a1, setA1] = useState('');
  const [a2, setA2] = useState('');
  const [newPin, setNewPin] = useState('');
  const [newPw, setNewPw] = useState('');
  const [msg, setMsg] = useState('');

  const submit = async () => {
    setMsg('');
    if (mode==='PIN'){
      const admin = findAdminByCompany(companyId);
      if (!admin || !admin.security) return setMsg('Invalid');
      const a1ok = await hashString(a1) === admin.security.a1Hash;
      const a2ok = await hashString(a2) === admin.security.a2Hash;
      if (!a1ok || !a2ok || !validatePin(newPin)) return setMsg('Invalid');
      const ok = await changeAdminPin(companyId, newPin);
      setMsg(ok? 'PIN updated.':'Failed');
      return;
    }
    const user = findUser(companyId, username);
    if (!user || !validatePassword(newPw)) return setMsg('Invalid');
    const ok = await changeUserPassword(companyId, username, newPw);
    setMsg(ok? 'Password updated.':'Failed');
  };

  return (
    <div className="min-h-screen w-full bg-gradient-to-br from-slate-50 to-slate-100 flex items-center justify-center p-6">
      <div className="w-[520px] max-w-full bg-white rounded-xl shadow-xl border border-slate-200 ring-1 ring-black/5 p-6">
        <h1 className="text-xl font-bold text-center">Account Recovery</h1>
        <div className="flex gap-2 justify-center mt-3">
          <Button variant={mode==='PIN'?'default':'outline'} onClick={()=>setMode('PIN')}>Admin PIN</Button>
          <Button variant={mode==='PASSWORD'?'default':'outline'} onClick={()=>setMode('PASSWORD')}>User Password</Button>
        </div>
        <div className="grid gap-3 mt-4">
          <div className="grid gap-1.5"><Label>Company ID</Label><Input value={companyId} onChange={e=>setCompanyId(e.target.value.toUpperCase())} placeholder="ABC01"/></div>
          {mode==='PASSWORD' && (
            <div className="grid gap-1.5"><Label>Username</Label><Input value={username} onChange={e=>setUsername(e.target.value)} /></div>
          )}
          {mode==='PIN' && (
            <>
              <div className="grid gap-1.5"><Label>Security Answer 1</Label><Input value={a1} onChange={e=>setA1(e.target.value)} /></div>
              <div className="grid gap-1.5"><Label>Security Answer 2</Label><Input value={a2} onChange={e=>setA2(e.target.value)} /></div>
              <div className="grid gap-1.5"><Label>New PIN</Label><Input value={newPin} onChange={e=>setNewPin(e.target.value)} placeholder="4 digits"/></div>
            </>
          )}
          {mode==='PASSWORD' && (
            <div className="grid gap-1.5"><Label>New Password</Label><Input value={newPw} onChange={e=>setNewPw(e.target.value)} placeholder="6+, 2U,2l,1symbol"/></div>
          )}
          {msg && <div className="text-sm text-gray-600">{msg}</div>}
          <Button onClick={submit}>Submit</Button>
        </div>
      </div>
      <Footer />
    </div>
  );
}
