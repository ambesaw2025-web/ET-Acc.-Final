import { AppHeader } from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useApp } from "@/state/app";
import { useMemo, useState } from "react";
import { etbToWords } from "@/lib/money";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";

function toCSV(rows: string[][]) {
  return rows.map(r => r.map(c => `"${c.replace(/"/g,'""')}"`).join(",")).join("\n");
}

export default function Reports() {
  const { state } = useApp();
  const [refQuery, setRefQuery] = useState("");
  const [status, setStatus] = useState<string>("All Status");
  const filtered = useMemo(() => state.transactions.filter(t => {
    if (refQuery && !t.id.toLowerCase().includes(refQuery.toLowerCase())) return false;
    if (status !== "All Status" && t.status !== status) return false;
    return true;
  }), [state.transactions, refQuery, status]);

  const exportCSV = () => {
    const rows = [["Ref","Type","Amount","Date"] as string[]].concat(filtered.map(t => [t.id, "Journal", String(t.lines.reduce((s,l)=>s+(l.nature==='Dr'?l.amount:0),0)), t.date]));
    const blob = new Blob([toCSV(rows)], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = "transactions.csv"; a.click(); URL.revokeObjectURL(url);
  };

  const [adviceRef, setAdviceRef] = useState("");
  const adviceTx = state.transactions.find(t => t.id === adviceRef);
  const amount = adviceTx ? adviceTx.lines.reduce((s,l)=>s+(l.nature==='Dr'?l.amount:0),0) : 0;

  const glTotals = useMemo(() => {
    const totals = new Map<string, { dr: number; cr: number }>();
    for (const t of state.transactions.filter(x=> x.status !== "Rejected" && x.status !== "Reversed")) {
      for (const l of t.lines) {
        const cur = totals.get(l.accountId) || { dr: 0, cr: 0 };
        if (l.nature === "Dr") cur.dr += l.amount; else cur.cr += l.amount;
        totals.set(l.accountId, cur);
      }
    }
    return totals;
  }, [state.transactions]);

  const exportGL = () => {
    const rows: string[][] = [["Account #","Name","Dr Total","Cr Total","Balance","Nature","Abnormal"]];
    state.coa.forEach(a => {
      const t = glTotals.get(a.id) || { dr: 0, cr: 0 };
      const bal = a.nature === "Dr" ? t.dr - t.cr : t.cr - t.dr;
      rows.push([a.id, a.name, t.dr.toFixed(2), t.cr.toFixed(2), bal.toFixed(2), a.nature, state.abnormalAccounts.includes(a.id)?"Yes":"No"]);
    });
    const blob = new Blob([toCSV(rows)], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = "gl_position.csv"; a.click(); URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <AppHeader />
      <main className="container py-6"><div className="bg-white rounded-xl border border-slate-200 ring-1 ring-black/5 shadow-sm p-6">
        <div className="mb-4 bg-gradient-to-r from-slate-800 to-slate-600 text-white h-12 px-4 rounded-md flex items-center justify-between">
          <div className="flex items-center gap-3"><span className="text-sm">📊</span><div className="font-medium">Reports Center</div></div>
          <div className="text-xs opacity-90">{state.company?.name || "Company"} • System Date: {state.systemDate}</div>
        </div>
        <Tabs defaultValue="tracking">
          <TabsList className="mb-4">
            <TabsTrigger value="tracking">Transaction Tracking</TabsTrigger>
            <TabsTrigger value="advice">Generate Advice</TabsTrigger>
            <TabsTrigger value="journal">Posting Journal</TabsTrigger>
            <TabsTrigger value="gl">GL Position</TabsTrigger>
          </TabsList>

          <TabsContent value="tracking">
            <Card className="p-4">
              <div className="flex items-center justify-between mb-2">
                <h3 className="font-semibold">Transaction Tracking <span className="ml-2 text-xs text-gray-400">[RPT-TRK-101]</span></h3>
                <div className="text-xs text-gray-500">Real-time based on current data</div>
              </div>
              <div className="flex flex-wrap items-center gap-2 mb-3">
                <Input placeholder="Reference Number" value={refQuery} onChange={(e)=>setRefQuery(e.target.value)} className="w-64"/>
                <select className="h-10 rounded-md border border-input bg-background px-3 text-sm" value={status} onChange={(e)=>setStatus(e.target.value)}>
                  <option>All Status</option>
                  <option>Pending</option>
                  <option>Approved</option>
                  <option>Rejected</option>
                  <option>Reversed</option>
                </select>
                <Button onClick={exportCSV}>Export CSV</Button>
                <Button variant="outline" onClick={()=>window.print()}>Print</Button>
              </div>
              {filtered.length === 0 ? (
                <div className="rounded border p-3 text-sm text-gray-500">No transactions match your filters. Try clearing filters or create a new transaction from Dashboard.</div>
              ) : (
                <div className="border rounded divide-y">
                  {filtered.map((t,i)=> (
                    <div key={t.id} className="grid grid-cols-[60px_1fr_120px_160px] gap-2 px-3 py-2 text-sm row-hover">
                      <div>{i+1}</div>
                      <div><button className="text-primary underline" onClick={()=>setAdviceRef(t.id)}>{t.id}</button></div>
                      <div>{t.lines.reduce((s,l)=>s+(l.nature==='Dr'?l.amount:0),0).toLocaleString()}</div>
                      <div>{t.date}</div>
                    </div>
                  ))}
                </div>
              )}
              <div className="mt-3 text-[11px] text-gray-500">Generated on {new Date().toLocaleString()} • {state.company?.name || "Company"} <span className="text-gray-400">[RPT-FTR-901]</span></div>
            </Card>
          </TabsContent>

          <TabsContent value="advice">
            <Card className="p-4">
              <div className="flex items-center justify-between mb-2">
                <h3 className="font-semibold">Generate Advice <span className="ml-2 text-xs text-gray-400">[RPT-ADV-102]</span></h3>
                <div className="text-xs text-gray-500">Reference-driven advice layout</div>
              </div>
              <div className="flex gap-2 mb-3">
                <Input placeholder="Transaction Ref #" value={adviceRef} onChange={(e)=>setAdviceRef(e.target.value)} />
                <Button onClick={()=>{}} className="bg-primary">Generate</Button>
              </div>
              {!adviceTx ? (
                <div className="text-sm text-gray-500">Enter a reference or pick from tracking to view advice.</div>
              ) : (
                <div id="advice-template" className="text-sm space-y-2">
                  <div className="border rounded-lg p-4">
                    <div className="flex items-center justify-between">
                      <div className="font-semibold">{state.company?.name}</div>
                      <div className="text-xs text-gray-500">Ref: {adviceTx.id}</div>
                    </div>
                    <div className="text-xs text-gray-600">Date: {adviceTx.date}</div>
                    <div className="mt-2">
                      <div className="font-medium">Transaction Detail</div>
                      <div className="text-xs text-gray-600">{adviceTx.narration || "Transaction"}</div>
                    </div>
                    <div className="border rounded p-2 mt-2">
                      {adviceTx.lines.map((l,i)=> (
                        <div key={i} className="flex justify-between"><span>{l.nature} · {l.accountId}</span><span>ETB {l.amount.toLocaleString()}</span></div>
                      ))}
                    </div>
                    <div className="text-xs text-gray-600 mt-1">Amount in Words: {etbToWords(amount)}</div>
                    <div className="text-[10px] text-gray-500 mt-4 italic">Thank you. This advice is not valid unless signed and accompanied by the official seal of the company.</div>
                  </div>
                  <div className="pt-3 flex gap-2">
                    <Button variant="outline" onClick={()=>window.print()}>Print Advice</Button>
                    <Button onClick={exportCSV}>Export as Excel</Button>
                    <Button variant="outline" onClick={()=>{
                      const html = document.getElementById('advice-template')?.outerHTML || '';
                      const w = window.open('', '_blank');
                      if (w){ w.document.write(`<html><head><title>Advice</title><style>body{font-family:Inter,system-ui,Arial;padding:24px}</style></head><body>${html}</body></html>`); w.document.close(); w.focus(); w.print(); }
                    }}>Export PDF</Button>
                  </div>
                  <div className="mt-3 text-[11px] text-gray-500">Generated on {new Date().toLocaleString()} • {state.company?.name || "Company"} <span className="text-gray-400">[RPT-FTR-901]</span></div>
                </div>
              )}
            </Card>
          </TabsContent>

          <TabsContent value="journal">
            <Card className="p-4">
              <div className="flex items-center justify-between mb-2">
                <h3 className="font-semibold">Posting Journal <span className="ml-2 text-xs text-gray-400">[RPT-JRN-103]</span></h3>
                <div className="text-xs text-gray-500">Chronological entries</div>
              </div>
              <div className="grid grid-cols-[160px_1fr_1fr_100px_120px_160px] text-sm border-b py-2">
                <div>Ref</div><div>Maker</div><div>Checker</div><div>Status</div><div>Amount</div><div>Date/Time</div>
              </div>
              {state.transactions.map(t => (
                <div key={t.id} className="grid grid-cols-[160px_1fr_1fr_100px_120px_160px] text-sm border-b py-2 row-hover">
                  <div className="font-mono">{t.id}</div><div>{t.makerId}</div><div>{t.checkerId||"-"}</div><div>{t.status}</div><div>{t.lines.reduce((s,l)=>s+(l.nature==='Dr'?l.amount:0),0).toLocaleString()}</div><div>{t.date}</div>
                </div>
              ))}
              <div className="mt-3 text-[11px] text-gray-500">Generated on {new Date().toLocaleString()} • {state.company?.name || "Company"} <span className="text-gray-400">[RPT-FTR-901]</span></div>
            </Card>
          </TabsContent>

          <TabsContent value="gl">
            <Card className="p-4">
              <div className="flex items-center justify-between mb-2">
                <h3 className="font-semibold">GL Position <span className="ml-2 text-xs text-gray-400">[RPT-GLP-104]</span></h3>
                <div className="flex items-center gap-2">
                  <Button onClick={exportGL}>Export CSV</Button>
                  <Button variant="outline" onClick={()=>window.print()}>Print</Button>
                </div>
              </div>
              <div className="grid grid-cols-[160px_1fr_100px_120px_120px_140px_100px] text-sm border-b py-2">
                <div>Account #</div><div>Name</div><div>Nature</div><div>Dr Total</div><div>Cr Total</div><div>Balance</div><div>Abnormal</div>
              </div>
              {state.coa.map(a => {
                const t = glTotals.get(a.id) || { dr: 0, cr: 0 };
                const bal = a.nature === "Dr" ? t.dr - t.cr : t.cr - t.dr;
                return (
                  <div key={a.id} className="grid grid-cols-[160px_1fr_100px_120px_120px_140px_100px] text-sm border-b py-2 row-hover">
                    <div>{a.id}</div><div>{a.name}</div><div>{a.nature}</div><div>{t.dr.toLocaleString()}</div><div>{t.cr.toLocaleString()}</div><div>{bal.toLocaleString()}</div><div className={state.abnormalAccounts.includes(a.id)?'text-red-600':''}>{state.abnormalAccounts.includes(a.id)?'Yes':'No'}</div>
                  </div>
                );
              })}
              <div className="mt-3 text-[11px] text-gray-500">Generated on {new Date().toLocaleString()} • {state.company?.name || "Company"} <span className="text-gray-400">[RPT-FTR-901]</span></div>
            </Card>
          </TabsContent>
        </Tabs>
      </div></main>
      <Footer />
    </div>
  );
}
