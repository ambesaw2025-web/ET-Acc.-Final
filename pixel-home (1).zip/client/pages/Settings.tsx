import { AppHeader } from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useApp } from "@/state/app";
import { useState } from "react";

export default function Settings() {
  const { endOfDay, reverseEOD, openClosedDay, state } = useApp();
  const [calendar, setCalendar] = useState<"Ethiopian" | "Gregorian" | "Mixed">("Gregorian");
  const runEod = () => {
    const res = endOfDay();
    alert(res.ok ? `EOD Success. New date: ${state.systemDate}` : `Blocked: ${res.error}`);
  };
  const role = state.session?.user.role || "Maker";
  const isAdmin = role === "Default Admin" || role === "Custom Admin";
  return (
    <div className="min-h-screen bg-slate-50">
      <AppHeader />
      <main className="container py-6"><div className="bg-white rounded-xl border border-slate-200 ring-1 ring-black/5 shadow-sm p-6 space-y-6">
        <section className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {isAdmin ? (
            <Card className="p-4 space-y-2">
              <h3 className="font-semibold">End of Day</h3>
              <p className="text-sm text-gray-600">Validation blocks if pending transactions or abnormal GL balances exist.</p>
              <div className="flex gap-2"><Button onClick={runEod}>Run EOD</Button><Button variant="outline" onClick={()=>reverseEOD()}>Reverse EOD</Button></div>
              <div className="mt-3">
                <div className="text-sm font-medium">Closed Days</div>
                <div className="text-xs text-gray-500">Click to reopen</div>
                <div className="max-h-40 overflow-auto divide-y">
                  {state.closedDays.map(d => (
                    <div key={d} className="flex items-center justify-between py-1 text-sm">
                      <div>{d}</div>
                      <Button size="sm" variant="outline" onClick={()=>openClosedDay(d)}>Open Closed Day</Button>
                    </div>
                  ))}
                </div>
              </div>
            </Card>
          ) : (
            <Card className="p-4 space-y-2">
              <h3 className="font-semibold">Profile</h3>
              <p className="text-sm text-gray-600">Update your profile and preferences.</p>
              <Button variant="outline">Edit Profile</Button>
            </Card>
          )}
          <Card className="p-4 space-y-2">
            <h3 className="font-semibold">Calendar Configuration</h3>
            <div className="flex gap-3 text-sm">
              {["Ethiopian","Gregorian","Mixed"].map(c => (
                <label key={c} className="inline-flex items-center gap-2"><input type="radio" name="cal" checked={calendar===c} onChange={()=>setCalendar(c as any)} /> {c}</label>
              ))}
            </div>
            <div className="text-xs text-gray-500">You have made Calendar Modifications... Are you sure? <span className="text-gray-400">[SET-CNF-301]</span></div>
          </Card>
        </section>
      </div></main>
      <Footer />
    </div>
  );
}
