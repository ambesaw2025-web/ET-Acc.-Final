import { useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { z } from "zod";
import { AccountingMethod, Company, NatureOfBusiness, genCompanyId, hashString, saveCompany, saveUsers, validatePin } from "@/lib/security";
import { useNavigate } from "react-router-dom";
import Logo from "@/components/branding/Logo";
import { initAntiTamper } from "@/lib/antiTamper";

const companySchema = z.object({
  name: z.string().min(2),
  address: z.string().optional(),
  contact: z.string().optional(),
  taxId: z.string().optional(),
  nature: z.custom<NatureOfBusiness>(),
});

const fySchema = z.object({
  method: z.custom<AccountingMethod>(),
  start: z.string(),
  firstMonth: z.number().min(1).max(12),
});

export default function Setup() {
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [company, setCompany] = useState<{ name: string; address?: string; contact?: string; taxId?: string; nature: NatureOfBusiness } | null>(null);
  const [fy, setFy] = useState<{ method: AccountingMethod; start: string; firstMonth: number } | null>(null);
  const [admin, setAdmin] = useState<{ fullName: string; pin: string; pin2: string; q1: string; a1: string; q2: string; a2: string }>({ fullName: "", pin: "", pin2: "", q1: "Mother's maiden name?", a1: "", q2: "City you were born?", a2: "" });
  const [useDefaultCoa, setUseDefaultCoa] = useState(true);
  const [showComplete, setShowComplete] = useState(false);

  useEffect(() => { return initAntiTamper(); }, []);

  const computedEnd = useMemo(() => {
    if (!fy?.start) return "";
    const d = new Date(fy.start);
    const end = new Date(d);
    end.setFullYear(d.getFullYear() + 1);
    end.setDate(end.getDate() - 1);
    return end.toISOString().slice(0, 10);
  }, [fy?.start]);

  const next = () => setStep((s) => Math.min(6, s + 1));
  const back = () => setStep((s) => Math.max(1, s - 1));

  const canNext = (() => {
    if (step === 1) return true;
    if (step === 2) return !!company && company.name?.trim().length >= 2 && !!company.nature;
    if (step === 3) return !!fy && !!fy.method && !!fy.start && fy.firstMonth >= 1 && fy.firstMonth <= 12;
    if (step === 4) return admin.fullName.trim().length > 0 && validatePin(admin.pin) && admin.pin === admin.pin2 && admin.a1.trim() && admin.a2.trim() ? true : false;
    if (step === 5) return true;
    return true;
  })();

  const complete = async () => {
    if (!company || !fy) return;
    if (admin.pin !== admin.pin2) return;
    const id = genCompanyId(company.name);
    const payload: Company = {
      id,
      name: company.name,
      address: company.address,
      contact: company.contact,
      taxId: company.taxId,
      nature: company.nature,
      fiscalStart: fy.start,
      fiscalEnd: computedEnd,
      firstMonth: fy.firstMonth,
      method: fy.method,
      createdAt: new Date().toISOString(),
    };
    saveCompany(payload);
    const pinHash = await hashString(admin.pin);
    const a1Hash = await hashString(admin.a1);
    const a2Hash = await hashString(admin.a2);
    saveUsers([
      {
        id: "admin",
        companyId: id,
        username: "admin",
        name: admin.fullName || "Default Admin",
        role: "Default Admin",
        status: "Active",
        pinHash,
        security: { q1: admin.q1, a1Hash, q2: admin.q2, a2Hash },
        createdAt: new Date().toISOString(),
      },
    ]);
    setShowComplete(true);
  };

  return (
    <div className="min-h-screen w-full et-pattern flex items-center justify-center p-6">
      <div className="w-[700px] max-w-full bg-white rounded-xl shadow-xl border border-slate-200 ring-1 ring-black/5">
        <div className="border-b px-6 py-4 flex items-center justify-between">
          <h2 className="font-semibold flex items-center gap-2">🛠️ First-Time Setup Wizard</h2>
          <div className="text-xs text-gray-500">Step {step} of 6</div>
        </div>
        <div className="p-6 min-h-[420px]">
          {step === 1 && (
            <div className="text-center">
              <Logo size={48} className="mx-auto mb-4" />
              <h3 className="text-xl font-bold">Welcome</h3>
              <p className="text-gray-600 mt-2">This wizard will guide you through initial configuration.</p>
            </div>
          )}
          {step === 2 && (
            <div className="grid gap-4">
              <div className="grid gap-2">
                <Label>Company Name</Label>
                <Input onChange={(e) => setCompany({ name: e.target.value, address: company?.address, contact: company?.contact, taxId: company?.taxId, nature: company?.nature || "Sole Proprietor" })} />
              </div>
              <div className="grid gap-2">
                <Label>Address</Label>
                <Input onChange={(e) => setCompany({ name: company?.name || "", address: e.target.value, contact: company?.contact, taxId: company?.taxId, nature: company?.nature || "Sole Proprietor" })} />
              </div>
              <div className="grid gap-2">
                <Label>Contact</Label>
                <Input onChange={(e) => setCompany({ name: company?.name || "", address: company?.address, contact: e.target.value, taxId: company?.taxId, nature: company?.nature || "Sole Proprietor" })} />
              </div>
              <div className="grid gap-2">
                <Label>Tax ID</Label>
                <Input onChange={(e) => setCompany({ name: company?.name || "", address: company?.address, contact: company?.contact, taxId: e.target.value, nature: company?.nature || "Sole Proprietor" })} />
              </div>
              <div className="grid gap-2">
                <Label>Nature of Business (immutable)</Label>
                <Select onValueChange={(v) => setCompany({ name: company?.name || "", address: company?.address, contact: company?.contact, taxId: company?.taxId, nature: v as NatureOfBusiness })}>
                  <SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger>
                  <SelectContent>
                    {[
                      "Sole Proprietor",
                      "Share Company",
                      "Private Limited Company",
                      "Partnership",
                      "NGO",
                      "Other",
                    ].map((n) => (
                      <SelectItem key={n} value={n}>{n}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          )}
          {step === 3 && (
            <div className="grid gap-4">
              <div className="grid gap-2">
                <Label>Accounting Method</Label>
                <Select onValueChange={(v) => setFy({ ...(fy || { start: "", firstMonth: 1 }), method: v as AccountingMethod })}>
                  <SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Cash">Cash</SelectItem>
                    <SelectItem value="Accrual">Accrual</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid gap-2">
                <Label>Fiscal Year Start Date</Label>
                <Input type="date" onChange={(e) => setFy({ ...(fy || { method: "Accrual", firstMonth: 1 }), start: e.target.value })} />
                <p className="text-xs text-gray-500">End Date auto-calculates: <b>{computedEnd || "--"}</b></p>
              </div>
              <div className="grid gap-2">
                <Label>First Month of FY</Label>
                <Input type="number" min={1} max={12} onChange={(e) => setFy({ ...(fy || { method: "Accrual", start: "" }), firstMonth: Number(e.target.value) })} />
              </div>
            </div>
          )}
          {step === 4 && (
            <div className="grid gap-4">
              <div className="grid gap-2">
                <Label>Default Admin Full Name</Label>
                <Input onChange={(e) => setAdmin({ ...admin, fullName: e.target.value })} />
              </div>
              <div className="grid gap-2">
                <Label>4-Digit PIN</Label>
                <Input type="password" maxLength={4} onChange={(e) => setAdmin({ ...admin, pin: e.target.value })} />
                {!validatePin(admin.pin) && admin.pin.length > 0 && (
                  <p className="text-xs text-red-600">PIN must be 4 digits and not a sequence or repeat.</p>
                )}
              </div>
              <div className="grid gap-2">
                <Label>Confirm PIN</Label>
                <Input type="password" maxLength={4} onChange={(e) => setAdmin({ ...admin, pin2: e.target.value })} />
                {admin.pin2 && admin.pin2 !== admin.pin && (
                  <p className="text-xs text-red-600">PINs do not match.</p>
                )}
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label>Security Question 1</Label>
                  <Input value={admin.q1} onChange={(e) => setAdmin({ ...admin, q1: e.target.value })} />
                  <Input placeholder="Answer" onChange={(e) => setAdmin({ ...admin, a1: e.target.value })} />
                </div>
                <div className="grid gap-2">
                  <Label>Security Question 2</Label>
                  <Input value={admin.q2} onChange={(e) => setAdmin({ ...admin, q2: e.target.value })} />
                  <Input placeholder="Answer" onChange={(e) => setAdmin({ ...admin, a2: e.target.value })} />
                </div>
              </div>
            </div>
          )}
          {step === 5 && (
            <div className="space-y-4">
              <h4 className="font-medium">Chart of Accounts</h4>
              <div className="flex items-center gap-3 text-sm">
                <label className="inline-flex items-center gap-2">
                  <input type="radio" name="coa" checked={useDefaultCoa} onChange={() => setUseDefaultCoa(true)} />
                  Use Default CoA (tailored to Nature of Business)
                </label>
                <label className="inline-flex items-center gap-2">
                  <input type="radio" name="coa" checked={!useDefaultCoa} onChange={() => setUseDefaultCoa(false)} />
                  Import Custom CoA
                </label>
              </div>
              <div className="rounded border p-3 text-sm text-gray-600">
                {useDefaultCoa ? (
                  <div>Default Chart of Accounts will be seeded based on your selected Nature of Business. You can add or deactivate accounts later in CoA Manager.</div>
                ) : (
                  <div>Import your custom CoA from CoA Manager after setup. Ensure your account numbers follow 8-digit format with categories and natures aligned.</div>
                )}
              </div>
            </div>
          )}
          {step === 6 && (
            <div className="text-center">
              <div className="mx-auto mb-4 h-12 w-12 rounded-full bg-green-100 text-green-700 flex items-center justify-center">✓</div>
              <h3 className="text-xl font-bold">Setup Complete</h3>
              <p className="text-gray-600 mt-2">Click Complete Setup to finalize and proceed to login.</p>
            </div>
          )}
        </div>
        <div className="border-t px-6 py-4 flex items-center justify-between">
          <div className="text-[11px] text-gray-500">Need help? You can revisit settings anytime after setup. <span className="text-gray-400">[STP-HNT-700]</span></div>
          <div className="flex items-center gap-2">
            <Button variant="ghost" onClick={back} disabled={step === 1}>Back</Button>
            {step < 6 ? (
              <Button onClick={next} disabled={!canNext}>Next</Button>
            ) : (
              <Button onClick={complete} disabled={!canNext}>Complete Setup</Button>
            )}
          </div>
        </div>
      </div>

      <Dialog open={showComplete} onOpenChange={setShowComplete}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Success <span className="ml-2 text-xs text-gray-400">[STP-CPL-200]</span></DialogTitle>
            <DialogDescription>
              Your company has been created. You can now log in using Company ID generated during setup.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button onClick={() => navigate("/login")}>Go to Login</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
