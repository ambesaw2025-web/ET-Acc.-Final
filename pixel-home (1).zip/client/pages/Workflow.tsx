import { AppHeader } from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useApp } from "@/state/app";
import { useState } from "react";
import { WorkflowModal } from "@/components/modals/WorkflowModal";

export default function Workflow(){
  const { state } = useApp();
  const [open, setOpen] = useState<string|undefined>();
  const pending = state.transactions.filter(t=>t.status==='Pending');
  return (
    <div className="min-h-screen bg-slate-50">
      <AppHeader />
      <main className="container py-6"><div className="bg-white rounded-xl border border-slate-200 ring-1 ring-black/5 shadow-sm p-6 space-y-6">
        <Card className="p-4">
          <h3 className="font-semibold mb-2">Pending Transactions</h3>
          <div className="divide-y">
            {pending.map(t=> (
              <div key={t.id} className="flex items-center justify-between py-2 text-sm">
                <div className="font-mono">{t.id}</div>
                <div>{t.narration||'Transaction'}</div>
                <div className="text-xs">{t.date}</div>
                <Button size="sm" onClick={()=>setOpen(t.id)}>Open</Button>
              </div>
            ))}
            {pending.length===0 && <div className="text-sm text-gray-500 py-2">No pending transactions.</div>}
          </div>
        </Card>
      </div></main>
      <Footer />
      <WorkflowModal open={!!open} onOpenChange={()=>setOpen(undefined)} txId={open} />
    </div>
  );
}
