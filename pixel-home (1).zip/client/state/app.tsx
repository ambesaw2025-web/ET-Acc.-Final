import React, { createContext, useContext, useEffect, useMemo, useRef, useState } from "react";
import { Company, UserRecord, loadCompany, loadUsers } from "@/lib/security";
import { toast } from "@/hooks/use-toast";

export type Role = UserRecord["role"];
export type TxStatus = "Draft" | "Pending" | "Approved" | "Rejected" | "Reversed";

export type GLNature = "Dr" | "Cr";
export interface GLAccount {
  id: string; // 8-digit
  name: string;
  category: "Asset" | "Liability" | "Equity" | "Income" | "Expense";
  nature: GLNature;
  active: boolean;
}

export interface JournalLine {
  accountId: string;
  amount: number; // ETB decimal approximated
  nature: GLNature; // Dr or Cr
}

export interface Transaction {
  id: string; // reference number
  date: string; // ISO date
  currency: "ETB";
  narration?: string;
  makerId: string;
  checkerId?: string;
  status: TxStatus;
  lines: JournalLine[]; // at least 2; sum Dr == sum Cr
  createdAt: string;
  approvedAt?: string;
}

export interface AuditLogEntry { id: string; when: string; who: string; action: string; details?: string }

export interface AppState {
  company: Company | null;
  users: UserRecord[];
  session?: { user: UserRecord } | null;
  coa: GLAccount[];
  transactions: Transaction[];
  systemDate: string; // ISO date fixed to GMT+3
  abnormalAccounts: string[]; // account ids
  audit: AuditLogEntry[];
  closedDays: string[]; // EOD history
}

function load<T>(key: string, fallback: T): T {
  const raw = localStorage.getItem(key);
  return raw ? (JSON.parse(raw) as T) : fallback;
}
function persist<T>(key: string, value: T) {
  localStorage.setItem(key, JSON.stringify(value));
}

function defaultCoA(): GLAccount[] {
  return [
    { id: "10000001", name: "Cash on Hand", category: "Asset", nature: "Dr", active: true },
    { id: "10000002", name: "Bank", category: "Asset", nature: "Dr", active: true },
    { id: "11000001", name: "Accounts Receivable", category: "Asset", nature: "Dr", active: true },
    { id: "12000001", name: "Inventory", category: "Asset", nature: "Dr", active: true },
    { id: "20000001", name: "Accounts Payable", category: "Liability", nature: "Cr", active: true },
    { id: "30000001", name: "Capital", category: "Equity", nature: "Cr", active: true },
    { id: "40000001", name: "Sales Revenue", category: "Income", nature: "Cr", active: true },
    { id: "50000001", name: "Cost of Goods Sold", category: "Expense", nature: "Dr", active: true },
    { id: "50000002", name: "Operating Expenses", category: "Expense", nature: "Dr", active: true },
  ];
}

function defaultCoAForNature(nature?: Company["nature"]): GLAccount[] {
  const base = defaultCoA();
  const extra: GLAccount[] = [];
  switch (nature) {
    case "NGO":
      extra.push(
        { id: "21000001", name: "Restricted Funds", category: "Liability", nature: "Cr", active: true },
        { id: "40010001", name: "Donor Grants", category: "Income", nature: "Cr", active: true },
        { id: "51000001", name: "Program Expenses", category: "Expense", nature: "Dr", active: true },
      );
      break;
    case "Sole Proprietor":
      extra.push(
        { id: "30010001", name: "Owner's Capital", category: "Equity", nature: "Cr", active: true },
        { id: "30010002", name: "Owner's Drawings", category: "Equity", nature: "Dr", active: true },
      );
      break;
    case "Share Company":
    case "Private Limited Company":
      extra.push(
        { id: "30020001", name: "Share Capital", category: "Equity", nature: "Cr", active: true },
        { id: "30020002", name: "Retained Earnings", category: "Equity", nature: "Cr", active: true },
      );
      break;
    case "Partnership":
      extra.push(
        { id: "30030001", name: "Partner Capital", category: "Equity", nature: "Cr", active: true },
        { id: "30030002", name: "Partner Current Account", category: "Equity", nature: "Cr", active: true },
      );
      break;
    default:
      break;
  }
  const map = new Map<string, GLAccount>();
  [...base, ...extra].forEach(a => { if (!map.has(a.id)) map.set(a.id, a); });
  return Array.from(map.values()).sort((a,b)=> a.id.localeCompare(b.id));
}

function toAddisDateISO(d: Date = new Date()) {
  // Keep local date but display with Africa/Addis_Ababa
  const tz = "Africa/Addis_Ababa";
  const parts = new Intl.DateTimeFormat("en-CA", { timeZone: tz, year: "numeric", month: "2-digit", day: "2-digit" })
    .formatToParts(d)
    .reduce<Record<string, string>>((acc, p) => { if (p.type !== "literal") acc[p.type] = p.value; return acc; }, {});
  return `${parts.year}-${parts.month}-${parts.day}`;
}

type Ctx = {
  state: AppState;
  login: (user: UserRecord) => void;
  logout: () => void;
  addTransaction: (tx: Omit<Transaction, "createdAt" | "currency" | "status"> & { status?: TxStatus }) => { ok: boolean; error?: string };
  setTransactionsStatus: (id: string, status: TxStatus, checkerId?: string) => void;
  setCoa: (updater: (prev: GLAccount[]) => GLAccount[]) => void;
  setUsersState: (updater: (prev: UserRecord[]) => UserRecord[]) => void;
  generateRef: (prefix?: string) => string;
  endOfDay: () => { ok: boolean; error?: string };
  reverseEOD: () => { ok: boolean; error?: string };
  openClosedDay: (day: string) => { ok: boolean; error?: string };
};
const AppCtx = createContext<Ctx>({} as any);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [company, setCompany] = useState<Company | null>(loadCompany());
  const [users, setUsers] = useState<UserRecord[]>(loadUsers());
  const [coa, setCoa] = useState<GLAccount[]>(load("et_coa", defaultCoA()));
  const [transactions, setTransactions] = useState<Transaction[]>(load("et_tx", [] as Transaction[]));
  const [session, setSession] = useState<{ user: UserRecord } | null>(load("et_session", null));
  const [systemDate, setSystemDate] = useState<string>(load("et_sysdate", toAddisDateISO()));
  const [audit, setAudit] = useState<AuditLogEntry[]>(load("et_audit", [] as AuditLogEntry[]));
  const [closedDays, setClosedDays] = useState<string[]>(load("et_closed_days", [] as string[]));
  const idleTimer = React.useRef<number | null>(null);
  const SESSION_TIMEOUT_MS = 15 * 60 * 1000;

  useEffect(() => persist("et_coa", coa), [coa]);
  useEffect(() => persist("et_tx", transactions), [transactions]);
  useEffect(() => persist("et_session", session), [session]);
  useEffect(() => persist("et_sysdate", systemDate), [systemDate]);
  useEffect(() => persist("et_audit", audit), [audit]);
  useEffect(() => persist("et_closed_days", closedDays), [closedDays]);

  // Seed default CoA when empty based on company nature
  useEffect(() => {
    if (coa.length === 0) {
      setCoa(() => defaultCoAForNature(company?.nature));
    }
  }, [coa.length, company?.nature]);

  // Session timeout with activity tracking
  useEffect(() => {
    function reset() {
      if (idleTimer.current) window.clearTimeout(idleTimer.current);
      if (session && SESSION_TIMEOUT_MS > 0) {
        idleTimer.current = window.setTimeout(() => {
          setSession(null);
          log("Session Timeout");
          toast({ title: "Session timed out", description: "You have been logged out due to inactivity. [SEC-SSN-401]" });
        }, SESSION_TIMEOUT_MS);
      }
    }
    reset();
    const events: (keyof WindowEventMap)[] = ["mousemove","keydown","click","scroll","touchstart","focus"];
    events.forEach(ev => window.addEventListener(ev, reset));
    return () => {
      events.forEach(ev => window.removeEventListener(ev, reset));
      if (idleTimer.current) window.clearTimeout(idleTimer.current);
    };
  }, [session]);

  const abnormalAccounts = useMemo(() => {
    // Simple running balance by nature; abnormal if sign opposite to normal nature
    const totals = new Map<string, number>();
    for (const tx of transactions.filter(t => t.status === "Approved")) {
      for (const l of tx.lines) {
        const k = l.accountId;
        const current = totals.get(k) || 0;
        totals.set(k, current + (l.nature === "Dr" ? l.amount : -l.amount));
      }
    }
    const result: string[] = [];
    for (const acc of coa) {
      const bal = totals.get(acc.id) || 0;
      if (acc.category === "Asset" || acc.category === "Expense") {
        if (bal < 0) result.push(acc.id);
      } else {
        if (bal > 0) result.push(acc.id);
      }
    }
    return result;
  }, [transactions, coa]);

  const login = (user: UserRecord) => setSession({ user });
  const logout = () => setSession(null);

  function log(action: string, details?: string) {
    const who = session?.user.username || "system";
    setAudit(prev => [{ id: `${Date.now()}`, when: new Date().toISOString(), who, action, details }, ...prev]);
  }

  const roleCan = (role: Role, perm: "create"|"view"|"edit"|"delete"|"authorize") => {
    const matrix: Record<Role, Record<string, boolean>> = {
      "Maker": { create: true, view: true, edit: true, delete: false, authorize: false },
      "Checker": { create: true, view: true, edit: true, delete: false, authorize: true },
      "Authorizer": { create: true, view: true, edit: true, delete: false, authorize: true },
      "Custom Admin": { create: true, view: true, edit: true, delete: false, authorize: true },
      "Default Admin": { create: true, view: true, edit: true, delete: true, authorize: true },
    } as any;
    return matrix[role]?.[perm] ?? false;
  };

  const generateRef = (prefix = "TXN") => {
    const date = new Date();
    const dd = String(date.getDate()).padStart(2, "0");
    const mm = String(date.getMonth() + 1).padStart(2, "0");
    const yy = String(date.getFullYear()).slice(-2);
    const seq = String(transactions.length + 1).padStart(4, "0");
    return `${prefix}${seq}-${dd}${mm}${yy}`;
  };

  const addTransaction: Ctx["addTransaction"] = (tx) => {
    const dr = tx.lines.filter(l => l.nature === "Dr").reduce((s, l) => s + l.amount, 0);
    const cr = tx.lines.filter(l => l.nature === "Cr").reduce((s, l) => s + l.amount, 0);
    if (Math.abs(dr - cr) > 0.0001) return { ok: false, error: "Unbalanced transaction" };
    const ref = tx.id || generateRef("INV");
    const record: Transaction = { ...tx, id: ref, currency: "ETB", status: tx.status || "Pending", createdAt: new Date().toISOString() };
    setTransactions(prev => [record, ...prev]);
    log("Create Transaction", ref);
    return { ok: true };
  };

  const setTransactionsStatus = (id: string, status: TxStatus, checkerId?: string) => {
    setTransactions(prev => prev.map(t => t.id === id ? { ...t, status, checkerId, approvedAt: status === "Approved" ? new Date().toISOString() : t.approvedAt } : t));
    log(`Set Tx Status -> ${status}`, id);
  };

  const endOfDay = () => {
    const hasPending = transactions.some(t => t.status === "Pending");
    if (hasPending) return { ok: false, error: "Pending transactions exist" };
    if (abnormalAccounts.length) return { ok: false, error: "Abnormal GL balances" };
    setClosedDays(prev => [systemDate, ...prev]);
    const d = new Date(systemDate);
    d.setDate(d.getDate() + 1);
    const next = toAddisDateISO(d);
    setSystemDate(next);
    log("End of Day", `Closed ${systemDate} -> Opened ${next}`);
    return { ok: true };
  };

  const reverseEOD = () => {
    if (closedDays.length === 0) return { ok: false, error: "No closed days" };
    const [last, ...rest] = closedDays;
    setClosedDays(rest);
    setSystemDate(last);
    log("Reverse EOD", `Reopened ${last}`);
    return { ok: true };
  };

  const openClosedDay = (day: string) => {
    if (!closedDays.includes(day)) return { ok: false, error: "Day not found" };
    setClosedDays(prev => prev.filter(d => d !== day));
    log("Open Closed Day", day);
    return { ok: true };
  };

  const state: AppState = { company, users, session: session || null, coa, transactions, systemDate, abnormalAccounts, audit, closedDays };

  return (
    <AppCtx.Provider value={{ state, login, logout, addTransaction, setTransactionsStatus, setCoa: (u)=>setCoa(prev=>u(prev)), setUsersState: (u)=>setUsers(prev=>u(prev)), generateRef, endOfDay, reverseEOD, openClosedDay }}>
      {children}
    </AppCtx.Provider>
  );
}

export function useApp() { return useContext(AppCtx); }
